"""One search run on a development set.

    python scripts/run_search.py --arm nsga2_gp --dev LSS --seed 0
    python scripts/run_search.py --arm nsga2_gp --dev LSS --seed 0 --pilot     # 10% engineering subsample

Arms: nsga2_gp, mapelites_gp, random (genetic programming and random search); retuned, greedy (deterministic, seed
ignored). The initial population (Lung-RADS v2022 and 99 random valid rules) depends only on the seed, so it is
identical across arms. Output: runs/<dev>[_pilot]/<arm>/s<seed>.json with every evaluated rule and its objectives on
the development screens.
"""
import argparse, json, os, sys, time

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from nlst_rules.data import load                                                       # noqa: E402
from nlst_rules.rules import Evaluator, load_rule, complexity                          # noqa: E402
from nlst_rules.gp import GPVariation, random_rule                                     # noqa: E402
from nlst_rules.search import Budget, nsga2, map_elites, random_search, nondominated   # noqa: E402
from nlst_rules.baselines import retuned_lungrads, retuned_rule, greedy_rules           # noqa: E402

ROOT = os.path.join(os.path.dirname(__file__), "..")
V2022 = os.path.join(ROOT, "rules", "comparators", "lungrads_v2022.json")
GP_ARMS, FIXED_ARMS = ("nsga2_gp", "mapelites_gp", "random"), ("retuned", "greedy")


def development_set(ds, dev, pilot):
    s = ds.screens
    mask = np.ones(len(s), bool) if dev == "ALL" else (s.network == dev).to_numpy()
    if pilot:                                       # fixed 10% of participants, for engineering runs only
        pids = np.sort(s.pid[mask].unique())
        keep = set(np.random.default_rng(12345).choice(pids, size=len(pids) // 10, replace=False))
        mask = mask & s.pid.isin(keep).to_numpy()
    return ds.subset(mask)


def initial_population(seed, size=100):
    rng = np.random.default_rng(10_000 + seed)
    return [load_rule(V2022)] + [random_rule(rng) for _ in range(size - 1)]


def record(ev, rule, **extra):
    m = ev.metrics(rule)
    return {"rule": rule, "sensitivity": m["sensitivity"], "fpr": m["fpr"], "length": complexity(rule), **extra}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", required=True, choices=GP_ARMS + FIXED_ARMS)
    ap.add_argument("--dev", required=True, choices=["LSS", "ACRIN", "ALL"])
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--budget", type=int, default=5000)
    ap.add_argument("--pilot", action="store_true")
    a = ap.parse_args()

    out = os.path.join(ROOT, "runs", a.dev + ("_pilot" if a.pilot else ""), a.arm)
    os.makedirs(out, exist_ok=True)
    dev = development_set(load(), a.dev, a.pilot)
    ev = Evaluator(dev)
    ref = record(ev, load_rule(V2022))
    rng = np.random.default_rng(a.seed)
    t = time.time()
    meta = {"arm": a.arm, "dev": a.dev, "seed": a.seed, "budget": a.budget, "pilot": a.pilot,
            "screens": len(dev.screens), "cancer_screens": int(dev.screens.case.sum())}

    if a.arm == "retuned":
        g = retuned_lungrads(ev)
        F = [{"sensitivity": x[4], "fpr": x[5], "length": 4, "t": x[:4]} for x in g]
        archive = [record(ev, retuned_rule(*r["t"])) for r in nondominated(F)]
    elif a.arm == "greedy":
        archive = [record(ev, r["rule"], fp_per_case=r["fp_per_case"]) for r in greedy_rules(ev)]
    else:
        budget = Budget(ev, a.budget)
        init = initial_population(a.seed)
        var = GPVariation(rng)
        {"nsga2_gp": lambda: nsga2(budget, init, var, rng), "mapelites_gp": lambda: map_elites(budget, init, var, rng),
         "random": lambda: random_search(budget, init, random_rule, rng)}[a.arm]()
        archive = budget.archive
        meta["stalled"] = budget.stalled
    meta["seconds"] = time.time() - t
    meta["evaluated"] = len(archive)
    with open(os.path.join(out, f"s{a.seed}.json"), "w") as f:
        json.dump({"meta": meta, "reference": ref, "archive": archive}, f)
    ok = [r for r in archive if r["sensitivity"] >= ref["sensitivity"] + 0.01]
    best = min(ok, key=lambda r: (r["fpr"], r["length"])) if ok else None
    print(json.dumps(meta), "| v2022 %.3f/%.4f" % (ref["sensitivity"], ref["fpr"]),
          "| best with sens >= v2022 + 1pp:", None if best is None else "%.3f/%.4f len %d" % (best["sensitivity"], best["fpr"], best["length"]))


if __name__ == "__main__":
    sys.exit(main())
