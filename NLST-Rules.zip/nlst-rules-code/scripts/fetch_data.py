"""Download the open NLST clinical tables from the NCI Imaging Data Commons and record their checksums.

    python scripts/fetch_data.py            # IDC release v25 into data/raw/idc_v25/

The tables are public (CC BY 4.0) and need no account. The manifest (data/raw/idc_v25/MANIFEST.json) records the
source URL, size and SHA-256 of every file, so that analyses can cite the exact release.
"""
import hashlib, json, os, sys, urllib.request

RELEASE = "v25"
TABLES = ["nlst_prsn", "nlst_screen", "nlst_ctab", "nlst_ctabc", "nlst_canc"]
URL = "https://idc-open-metadata.s3.amazonaws.com/bigquery_export/idc_{rel}_clinical/{table}/000000000000.parquet"
OUT = os.path.join(os.path.dirname(__file__), "..", "data", "raw", f"idc_{RELEASE}")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    os.makedirs(OUT, exist_ok=True)
    manifest = {"source": "NCI Imaging Data Commons, clinical export", "release": RELEASE, "licence": "CC BY 4.0",
                "files": {}}
    for table in TABLES:
        url = URL.format(rel=RELEASE, table=table)
        path = os.path.join(OUT, f"{table}.parquet")
        if not os.path.exists(path):
            urllib.request.urlretrieve(url, path)
        manifest["files"][table] = {"url": url, "bytes": os.path.getsize(path), "sha256": sha256(path)}
        print(f"{table:12s} {manifest['files'][table]['bytes']:>9d} bytes  {manifest['files'][table]['sha256'][:16]}")
    with open(os.path.join(OUT, "MANIFEST.json"), "w") as f:
        json.dump(manifest, f, indent=2)


if __name__ == "__main__":
    sys.exit(main())
