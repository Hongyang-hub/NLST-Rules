"""Examples of test screens that the selected rules and Lung-RADS v2022 classify differently (descriptive, post hoc).

    python scripts/examples.py

The discordant pooled test screens fall into four groups: cancer screens and screens without cancer, each positive only
under Lung-RADS v2022 or only under the selected rule. For a discordant screen, the decisive nodule is the largest nodule
that is positive under the rule that calls the screen positive (no discordant screen is in the 4X layer, which is the
same for both rules); its pattern is its status (baseline, new or growing) and attenuation. Examples are chosen by a
fixed procedure, not by inspection: in each group, the most frequent pattern (for the cancer groups, the more frequent
histology class within it, bronchioloalveolar carcinoma or other); within it, the screen whose decisive nodule has the
median diameter (lower median after sorting by diameter, number of nodules, direction, round and row); for the cancer
groups also the most advanced stage within the pattern, with the same median rule among ties.
The selected rules are read from results/primary.json; nothing is re-selected. Writes results/examples.json.
"""
import json, os, sys

import numpy as np

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))
from nlst_rules.data import load, SOLID, PART, GGO          # noqa: E402
from nlst_rules.rules import Evaluator, load_rule           # noqa: E402

V2022 = load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v2022.json"))
ATT = {SOLID: "solid", PART: "part-solid", GGO: "ground-glass"}
GROUPS = ("cancer_ref_only", "cancer_new_only", "control_ref_only", "control_new_only")


def firing_clause(ev, rule, j):
    """The first clause of the rule that makes nodule j positive."""
    for c in rule["clauses"]:
        if Evaluator.nodule_positive(ev, {"clauses": [c]})[j]:
            return c
    return None


def negative_reason(ev, rule, j):
    """Why the other rule calls nodule j negative: the lowest threshold among its clauses that match the nodule apart
    from size, or None when no clause covers this kind of nodule."""
    th = [c["min_size"] for c in rule["clauses"]
          if Evaluator.nodule_positive(ev, {"clauses": [dict(c, min_size=0.0)]})[j]]
    return min(th) if th else None


def discordant():
    P = json.load(open(os.path.join(ROOT, "results", "primary.json")))
    ds = load()
    out = []
    for d, v in P["directions"].items():
        test = d.split("->")[1]
        rule = v["selected"]["rule"]
        t = ds.subset((ds.screens.network == test).to_numpy())
        ev = Evaluator(t)
        pos = {"new": ev.screen_positive(rule), "ref": ev.screen_positive(V2022)}
        npos = {"new": ev.nodule_positive(rule), "ref": ev.nodule_positive(V2022)}
        S, N = t.screens.reset_index(drop=True), t.nodules.reset_index(drop=True)
        for i in np.where(pos["new"] != pos["ref"])[0]:
            assert not S.x4[i]
            by = "new" if pos["new"][i] else "ref"
            idx = np.where((N.row.to_numpy() == i) & npos[by])[0]
            j = idx[np.argmax(N["mean"].to_numpy()[idx])]
            nod = N.iloc[j]
            status = "baseline" if nod.k == 0 else ("growing" if nod.growing else "new")
            case = bool(S.case[i])
            out.append({
                "group": ("cancer" if case else "control") + f"_{by}_only", "direction": d, "row": int(i), "k": int(S.k[i]),
                "status": status, "attenuation": ATT[int(nod.att)], "diameter": float(nod["mean"]),
                "long": float(nod["long"]), "spiculated": bool(nod.spiculated), "lobe": None if np.isnan(nod.lobe) else int(nod.lobe),
                "n_nodules": int((N.row.to_numpy() == i).sum()), "nlst_positive": bool(S.nlst_positive[i]),
                "clause": firing_clause(ev, rule if by == "new" else V2022, j),
                "other_threshold": negative_reason(ev, V2022 if by == "new" else rule, j),
                "other_nodules": sorted((float(x) for x in N["mean"].to_numpy()[(N.row.to_numpy() == i)]), reverse=True)[1:],
                "lung_cancer": bool(S.lc[i]), "days_to_diagnosis": float(S.dx[i] - S.d[i]) if S.lc[i] else None,
                "stage": code(S.stage[i]), "histology": code(S.histology[i]),
                "bac": bool(S.bac[i]), "case": case})
    return out


def code(v):
    return None if v is None or np.isnan(v) else int(v)


def median_pick(xs):
    xs = sorted(xs, key=lambda x: (x["diameter"], x["n_nodules"], x["direction"], x["k"], x["row"]))
    return xs[(len(xs) - 1) // 2]


def main():
    D = discordant()
    res = {}
    for g in GROUPS:
        xs = [x for x in D if x["group"] == g]
        pats = {}
        for x in xs:
            pats.setdefault(f"{x['status']} {x['attenuation']}", []).append(x)
        dist = sorted(((p, len(v), float(np.median([x["diameter"] for x in v])), min(x["diameter"] for x in v),
                        max(x["diameter"] for x in v)) for p, v in pats.items()), key=lambda r: (-r[1], r[0]))
        top = pats[dist[0][0]]
        typical = top
        if g.startswith("cancer"):
            bac = [x for x in top if x["bac"]]
            typical = bac if len(bac) > len(top) - len(bac) else [x for x in top if not x["bac"]]
        ex = [dict(median_pick(typical), pick="median diameter in the most frequent pattern")]
        if g.startswith("cancer"):
            worst = max(x["stage"] for x in top)
            w = median_pick([x for x in top if x["stage"] == worst])
            if (w["direction"], w["row"]) != (ex[0]["direction"], ex[0]["row"]):
                ex.append(dict(w, pick="most advanced stage in the most frequent pattern"))
        res[g] = {"n": len(xs), "patterns": [{"pattern": p, "n": n, "median": m, "min": lo, "max": hi}
                                             for p, n, m, lo, hi in dist], "examples": ex}
    json.dump(res, open(os.path.join(ROOT, "results", "examples.json"), "w"), indent=1)
    for g, r in res.items():
        print(g, r["n"], r["patterns"][0])
        for x in r["examples"]:
            print("   ", x["direction"], x["k"], x["status"], x["attenuation"], x["diameter"], x["n_nodules"], x["stage"],
                  x["histology"], x["days_to_diagnosis"], x["other_threshold"], x["other_nodules"], x["lung_cancer"])


if __name__ == "__main__":
    sys.exit(main())
