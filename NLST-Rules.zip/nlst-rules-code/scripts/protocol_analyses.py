"""Secondary and sensitivity analyses that scripts/evaluate.py does not implement.

    python scripts/protocol_analyses.py

Implemented after the primary evaluation (disclosed as such). The selected rules are read from results/primary.json and
results/final_rule.json; nothing is re-selected. Writes results/protocol.json.
"""
import json, os, sys

import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.dirname(__file__))
from nlst_rules.data import load, RAW, SOLID, PART, GGO, _num          # noqa: E402
from nlst_rules.rules import Evaluator, load_rule                         # noqa: E402
from nlst_rules.evaluate import compare, tango_ci                         # noqa: E402

V2022 = load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v2022.json"))
V10 = load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v10.json"))
IELCAP = {"clauses": [{"round": "baseline", "status": "all", "attenuation": ["solid", "part_solid"], "min_size": 6.0},
                      {"round": "baseline", "status": "all", "attenuation": ["ggo"], "min_size": 8.0}]}
P = json.load(open(os.path.join(ROOT, "results", "primary.json")))
FINAL = json.load(open(os.path.join(ROOT, "results", "final_rule.json")))["selected"]["rule"]
DIRECTIONS = [("LSS", "ACRIN"), ("ACRIN", "LSS")]
LOBES = {"locrup": 1, "locrmid": 2, "locrlow": 3, "loclup": 4, "loclin": 5, "locllow": 6}
CAT = {0: "2", 1: "3", 2: "4A", 3: "4B"}


def subset(ds, net):
    return ds.subset((ds.screens.network == net).to_numpy())


def pooled(ds, rule_new=None, rule_ref=V2022):
    """Pooled test screens with positivity of the selected rule of each direction and of the reference."""
    out = []
    for dev, test in DIRECTIONS:
        t = subset(ds, test)
        ev = Evaluator(t)
        s = t.screens.copy()
        new = P["directions"][f"{dev}->{test}"]["selected"]["rule"] if rule_new is None else rule_new
        s["pos_new"], s["pos_ref"], s["direction"] = ev.screen_positive(new), ev.screen_positive(rule_ref), f"{dev}->{test}"
        out.append((t, ev, s, new))
    return out


def stack(parts):
    return pd.concat([s for _, _, s, _ in parts], ignore_index=True)


def endpoints(S, seed=11):
    r = compare(S.pos_new.to_numpy(), S.pos_ref.to_numpy(), S, n_boot=10_000, seed=seed)
    return {k: r[k] for k in ("cancer_screens", "control_screens", "discordant_new_only", "discordant_ref_only", "sens_new",
                              "sens_ref", "fpr_new", "fpr_ref", "sens_diff", "fpr_diff", "criterion_sens", "criterion_fpr", "success")}


# --- dataset variants of the prespecified sensitivity analyses -------------------------------------------------------
def variant_missing_as_new(ds):
    n = ds.nodules.copy()
    n["new"] = n["new"] | ((n.k > 0) & ~n.has_comparison)
    return type(ds)(ds.screens, n)


def variant_missing_excluded(ds):
    n = ds.nodules[~((ds.nodules.k > 0) & ~ds.nodules.has_comparison)].reset_index(drop=True)
    s = ds.screens.copy()
    s["n_nodules"] = np.bincount(n.row, minlength=len(s))
    return type(ds)(s, n)


def variant_window(ds, days):
    s = ds.screens.copy()
    end = s.next_d.fillna(s.d + days)                                  # next completed screen, or `days` after the last
    s["case"] = s.lc & (s.dx >= s.d) & (s.dx < end)
    s["bac"] = s.case & s.histology.between(8250, 8254)
    return type(ds)(s, ds.nodules)


def short_followup_mask(S):
    """Screens without cancer of participants without lung cancer whose cancer-free follow-up after the screen is < 1 year."""
    return (~S.case & ~S.lc & ((S.cancer_free_days - S.d) < 365)).to_numpy()


# --- Lung-RADS v2022 categories of positive nodules ---------------------------------------------
def v2022_category(ev, nod):
    """Approximate v2022 category per nodule (0 = 2, 1 = 3, 2 = 4A, 3 = 4B). Solid nodules by size, new or growing status;
    part-solid nodules (solid component not recorded) at 3, or 4A when growing; ground-glass nodules at 3 when >= 30 mm."""
    size, base = ev.size, ev.round["baseline"]
    new, grow = ev.status["new"] & ~base, ev.status["growing"]
    att = nod["att"].to_numpy()
    cat = np.zeros(len(size), int)
    solid = att == SOLID
    cat = np.where(solid & base, np.select([size >= 15, size >= 8, size >= 6], [3, 2, 1], 0), cat)
    cat = np.where(solid & ~base & grow, np.where(size >= 8, 3, 2), cat)
    cat = np.where(solid & ~base & new & ~grow, np.select([size >= 8, size >= 6, size >= 4], [3, 2, 1], 0), cat)
    part = att == PART
    cat = np.where(part & (base | new) & (size >= 6), 1, cat)
    cat = np.where(part & ~base & new & (size < 6), 1, cat)
    cat = np.where(part & ~base & grow, 2, cat)
    ggo = att == GGO
    cat = np.where(ggo & (base | new | grow) & (size >= 30), 1, cat)
    return cat


def screen_category(ev, nod, rule, x4):
    """Highest category per screen under a rule: positive nodules take max(3, v2022 category); 4X layer = 4 (4X)."""
    pos = ev.nodule_positive(rule)
    c = np.where(pos, np.maximum(1, v2022_category(ev, nod)), 0)
    out = np.zeros(ev.n_screens, int)
    np.maximum.at(out, ev.row, c)
    return np.where(x4 & (out < 2), 4, out)


# --- other helpers -----------------------------------------------------------------------------------------------------
def kappa(a, b):
    a, b = np.asarray(a, bool), np.asarray(b, bool)
    po = (a == b).mean()
    pe = a.mean() * b.mean() + (1 - a.mean()) * (1 - b.mean())
    return float((po - pe) / (1 - pe))


def gee_difference(S, mask):
    """GEE (binomial, identity link, exchangeable, robust SE) of positivity on rule indicator, clustered by participant."""
    import statsmodels.api as sm
    sub = S[mask]
    y = np.concatenate([sub.pos_new.to_numpy(), sub.pos_ref.to_numpy()]).astype(float)
    x = np.concatenate([np.ones(len(sub)), np.zeros(len(sub))])
    g = np.concatenate([sub.pid.to_numpy(), sub.pid.to_numpy()]).astype(int)
    o = np.argsort(g, kind="stable")
    X = sm.add_constant(x[o])
    fam = sm.families.Binomial(link=sm.families.links.Identity())
    res = sm.GEE(y[o], X, groups=g[o], family=fam, cov_struct=sm.cov_struct.Exchangeable()).fit()
    est, se = float(res.params[1]), float(res.bse[1])
    return [est, est - 1.959963984540054 * se, est + 1.959963984540054 * se]


def brock(nod, screens, prsn):
    """Brock (PanCan) full model with spiculation (McWilliams 2013); family history absent; emphysema from CT code 59."""
    s = screens.iloc[nod.row.to_numpy()]
    p = prsn.set_index("pid").loc[s.pid.to_numpy()]
    age, female = _num(p.age).to_numpy(), (_num(p.gender) == 2).to_numpy()
    size = np.clip(nod["long"].to_numpy(), 1, None)
    att = nod["att"].to_numpy()
    lo = (0.0287 * (age - 62) + 0.6011 * female + 0.2953 * s.emphysema.to_numpy()
          - 5.3854 * ((size / 10) ** -0.5 - 1.58113883) - 0.1276 * (att == GGO) + 0.377 * (att == PART)
          + 0.6581 * nod.upper_lobe.to_numpy() - 0.0824 * (s.n_nodules.to_numpy() - 4) + 0.7729 * nod.spiculated.to_numpy()
          - 6.7892)
    return 1 / (1 + np.exp(-lo))


def main():
    ds = load()
    prsn = pd.read_parquet(os.path.join(RAW, "nlst_prsn.parquet"))
    prsn["pid"] = prsn.pid.astype(ds.screens.pid.dtype)
    out = {}

    # 1. prespecified sensitivity analyses of the co-primary endpoints
    sa = {}
    sa["missing_comparison_as_new"] = endpoints(stack(pooled(variant_missing_as_new(ds))))
    sa["missing_comparison_excluded"] = endpoints(stack(pooled(variant_missing_excluded(ds))))
    S = stack(pooled(ds))
    m = ~short_followup_mask(S)
    sa["short_followup_controls_excluded"] = {"excluded": int((~m).sum()), **endpoints(S[m].reset_index(drop=True))}
    sa["two_year_window"] = endpoints(stack(pooled(variant_window(ds, 730))))
    sa["gee"] = {"sensitivity": gee_difference(S, S.case.to_numpy()), "fpr": gee_difference(S, ~S.case.to_numpy())}
    out["sensitivity_analyses"] = sa

    # 2. clinically significant cancer (excluding bronchioloalveolar carcinoma; no in situ codes in the tables)
    nb = (~S.bac).to_numpy()
    case = S.case.to_numpy() & nb
    b = int((S.pos_new & ~S.pos_ref).to_numpy()[case].sum()); c = int((~S.pos_new & S.pos_ref).to_numpy()[case].sum())
    out["clinically_significant"] = {"cancer_screens": int(case.sum()), "sens_new": float(S.pos_new.to_numpy()[case].mean()),
                                     "sens_ref": float(S.pos_ref.to_numpy()[case].mean()), "discordant_new_only": b,
                                     "discordant_ref_only": c, "sens_diff": tango_ci(b, c, int(case.sum()))}
    canc = pd.read_parquet(os.path.join(RAW, "nlst_canc.parquet"))
    out["in_situ_codes_in_tables"] = int((_num(canc.lc_behav) == 2).sum())
    stage = S.stage.to_numpy()
    adv = S.case.to_numpy() & (stage >= 310) & (stage < 900)
    out["stage_iii_iv"] = {"cancer_screens": int(adv.sum()), "sens_new": float(S.pos_new.to_numpy()[adv].mean()),
                           "sens_ref": float(S.pos_ref.to_numpy()[adv].mean())}

    # 3. categories: PPV by category and results at 4A or higher
    cats = {}
    for name in ("new", "ref"):
        allc = []
        for (t, ev, s, rule) in pooled(ds):
            allc.append(screen_category(ev, t.nodules, rule if name == "new" else V2022, s.x4.to_numpy()))
        cats[name] = np.concatenate(allc)
    S["cat_new"], S["cat_ref"] = cats["new"], cats["ref"]
    ppv = {}
    for name in ("new", "ref"):
        ppv[name] = {lab: {"screens": int((S[f"cat_{name}"] == k).sum()),
                           "cancers": int((S.case & (S[f"cat_{name}"] == k)).sum()),
                           "ppv": float(S.case[S[f"cat_{name}"] == k].mean()) if (S[f"cat_{name}"] == k).any() else None}
                     for k, lab in ((1, "3"), (2, "4A"), (3, "4B"), (4, "4X"))}
    out["ppv_by_category"] = ppv
    S4 = S.copy()
    S4["pos_new"], S4["pos_ref"] = (S.cat_new >= 2).to_numpy(), (S.cat_ref >= 2).to_numpy()
    out["at_4A_or_higher"] = endpoints(S4, seed=12)

    # 4. cumulative probability of at least one false positive over three rounds (participants without a cancer screen)
    g = S.groupby("pid")
    full = (g.k.nunique() == 3) & ~g.case.any()
    fp_new = g.apply(lambda x: (x.pos_new & ~x.case).any(), include_groups=False)
    fp_ref = g.apply(lambda x: (x.pos_ref & ~x.case).any(), include_groups=False)
    out["cumulative_false_positive"] = {"participants": int(full.sum()), "new": float(fp_new[full].mean()),
                                        "ref": float(fp_ref[full].mean())}

    # 5. lobe-matched sensitivity and lead time
    loc = prsn.set_index("pid")[list(LOBES)].apply(_num)
    lobes_of = {pid: {LOBES[c] for c in LOBES if row[c] == 1} for pid, row in loc.iterrows()}
    norm = lambda l: 4 if l == 5 else l                     # lingula counted with the left upper lobe
    lobe_res, lead = {"new": [], "ref": []}, {"eligible": 0, "new": 0, "ref": 0, "new_lobe": 0, "ref_lobe": 0}
    unknown_lobe = 0
    for (t, ev, s, rule) in pooled(ds):
        nod = t.nodules
        posn = {"new": ev.nodule_positive(rule), "ref": ev.nodule_positive(V2022)}
        poss = {"new": s.pos_new.to_numpy(), "ref": s.pos_ref.to_numpy()}
        key = {(p, k): r for p, k, r in zip(s.pid, s.k, s.row)}
        nl = np.array([norm(x) for x in nod.lobe.to_numpy()])
        nrow = nod.row.to_numpy()
        for r in np.flatnonzero(s.case.to_numpy()):
            pid, k = s.pid.iat[r], s.k.iat[r]
            L = list({norm(l) for l in lobes_of.get(pid, set())})
            if not L:
                unknown_lobe += 1
                continue
            in_lobe = (nrow == r) & np.isin(nl, L)
            for name in ("new", "ref"):                      # a positive nodule in the lobe of the cancer, or the 4X layer
                lobe_res[name].append(bool(posn[name][in_lobe].any()) or bool(s.x4.iat[r]))
            if k > 0 and (pid, k - 1) in key:
                r0 = key[(pid, k - 1)]
                prev = (nrow == r0) & np.isin(nl, L)
                if prev.any():
                    lead["eligible"] += 1
                    for name in ("new", "ref"):
                        lead[name] += int(poss[name][r0])
                        lead[f"{name}_lobe"] += int(posn[name][prev].any())
    out["lobe_matched_sensitivity"] = {"new": float(np.mean(lobe_res["new"])), "ref": float(np.mean(lobe_res["ref"])),
                                       "cancer_screens": len(lobe_res["new"]), "lobe_unknown": unknown_lobe}
    out["lead_time"] = lead

    # 6. verification bias
    nlst = S.nlst_positive.to_numpy(); cs = S.case.to_numpy()
    out["verification"] = {"control_pos_new_nlst_negative": int((S.pos_new.to_numpy() & ~nlst & ~cs).sum()),
                           "control_pos_ref_nlst_negative": int((S.pos_ref.to_numpy() & ~nlst & ~cs).sum()),
                           "cancer_screens_nlst_negative": int((~nlst & cs).sum()),
                           "cancer_nlst_negative_pos_new": int((S.pos_new.to_numpy() & ~nlst & cs).sum()),
                           "cancer_nlst_negative_pos_ref": int((S.pos_ref.to_numpy() & ~nlst & cs).sum())}

    # 7. agreement between the three rules (kappa per screen, all screens) and comparators on the pooled test screens
    ev_all = Evaluator(ds)
    rules3 = {"LSS": P["directions"]["LSS->ACRIN"]["selected"]["rule"], "ACRIN": P["directions"]["ACRIN->LSS"]["selected"]["rule"],
              "ALL": FINAL}
    pos3 = {k: ev_all.screen_positive(r) for k, r in rules3.items()}
    out["kappa"] = {f"{a}-{b}": kappa(pos3[a], pos3[b]) for a, b in (("LSS", "ACRIN"), ("LSS", "ALL"), ("ACRIN", "ALL"))}
    comp = {}
    base = S.k.to_numpy() == 0
    for name, rule in (("lungrads_v10", V10), ("ielcap_baseline", IELCAP)):
        pos = np.concatenate([ev.screen_positive(rule) for (_, ev, _, _) in pooled(ds)])
        m = base if name == "ielcap_baseline" else np.ones(len(S), bool)
        comp[name] = {"sensitivity": float(pos[m & cs].mean()), "fpr": float(pos[m & ~cs].mean()), "baseline_only": bool(name == "ielcap_baseline")}
    comp["nlst"] = {"sensitivity": float(nlst[cs].mean()), "fpr": float(nlst[~cs].mean()), "baseline_only": False}
    # Brock at baseline: screen positive when any nodule reaches the PanCan management thresholds (6%, 30%), or 4X layer
    for thr in (0.06, 0.30):
        pos = []
        for (t, ev, s, _) in pooled(ds):
            pr = brock(t.nodules, t.screens, prsn)
            hit = np.zeros(len(s), bool); hit[t.nodules.row.to_numpy()[pr >= thr]] = True
            pos.append(hit | s.x4.to_numpy())
        pos = np.concatenate(pos)
        comp[f"brock_{int(thr * 100)}pct_baseline"] = {"sensitivity": float(pos[base & cs].mean()), "fpr": float(pos[base & ~cs].mean()),
                                                     "baseline_only": True}
    comp["selected_baseline"] = {"sensitivity": float(S.pos_new.to_numpy()[base & cs].mean()), "fpr": float(S.pos_new.to_numpy()[base & ~cs].mean()), "baseline_only": True}
    comp["v2022_baseline"] = {"sensitivity": float(S.pos_ref.to_numpy()[base & cs].mean()), "fpr": float(S.pos_ref.to_numpy()[base & ~cs].mean()), "baseline_only": True}
    out["comparators_pooled_test"] = comp

    # 8. objective 4: re-tuned Lung-RADS versus the selected rules (selected from the re-tuned arm alone)
    from evaluate import pool as _unused, runs                      # noqa: F401
    from nlst_rules.evaluate import select
    obj4 = {}
    for arm in ("retuned", "greedy"):
        parts = []
        for dev, test in DIRECTIONS:
            d = json.load(open(runs(dev, arm)[0]))
            ref = Evaluator(subset(ds, dev)).metrics(V2022)
            sel = select([{**r, "arm": arm, "seed": 0} for r in d["archive"]], ref)
            t = subset(ds, test); ev = Evaluator(t); s = t.screens.copy()
            s["pos_new"], s["pos_ref"] = ev.screen_positive(sel["rule"]), ev.screen_positive(V2022)
            parts.append(s)
            obj4.setdefault(arm, {})[f"rule_{dev}"] = sel["rule"]
        obj4[arm]["pooled"] = endpoints(pd.concat(parts, ignore_index=True), seed=13)
    out["objective4_single_arm_selection"] = obj4

    json.dump(out, open(os.path.join(ROOT, "results", "protocol.json"), "w"), indent=1, default=float)
    print("written results/protocol.json")


if __name__ == "__main__":
    main()
