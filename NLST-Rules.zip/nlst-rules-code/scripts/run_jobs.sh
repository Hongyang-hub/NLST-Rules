#!/bin/bash
# Run the jobs listed in $1 (arguments of run_search.py, one per line) with $2 in parallel.
# Usage: nohup bash scripts/run_jobs.sh runs/jobs_cpu.txt 4 > logs/jobs_cpu.log 2>&1 &
cd "$(dirname "$0")/.."
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
PY=${PY:-python}
grep -v -e '^\s*$' -e '^#' "$1" | xargs -P "$2" -I{} bash -c "$PY scripts/run_search.py {} || echo 'FAILED: {}'"
echo "$(date '+%F %T') all jobs of $1 finished"
