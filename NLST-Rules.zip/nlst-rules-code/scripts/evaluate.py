"""Selection, out-of-network evaluation and secondary analyses.

    python scripts/evaluate.py            # refuses to run until every arm of the candidate pool is complete
    python scripts/evaluate.py --dry-run  # code check on the 10% LSS pilot subsample only, split into two halves

Writes results/primary.json (selected rules, co-primary endpoints, success criteria), results/secondary.json,
results/methods.json (comparison of search arms) and results/final_rule.json (rule selected on all participants).
The test network is touched only here, and only after all development runs of the candidate pool exist.
"""
import glob, json, os, sys

import numpy as np
import pandas as pd

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))
from nlst_rules.data import load, RAW, SOLID, _num                     # noqa: E402
from nlst_rules.rules import Evaluator, load_rule, render, complexity  # noqa: E402
from nlst_rules.evaluate import select, compare, tango_ci, bootstrap_fpr_difference  # noqa: E402

V2022 = load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v2022.json"))
POOL = {"retuned": 1, "greedy": 1, "nsga2_gp": 20, "mapelites_gp": 20, "random": 20}
DIRECTIONS = [("LSS", "ACRIN"), ("ACRIN", "LSS")]
OUT = os.path.join(ROOT, "results")


DRY = "--dry-run" in sys.argv


def runs(dev, arm):
    if DRY:
        dev = "LSS_pilot"
    return sorted(glob.glob(os.path.join(ROOT, "runs", dev, arm, "s*.json")))


def check_complete():
    missing = [(dev, arm, len(runs(dev, arm)), n) for dev in ("LSS", "ACRIN", "ALL") for arm, n in POOL.items()
               if len(runs(dev, arm)) < n]
    if missing:
        sys.exit("candidate pool incomplete; test networks not touched:\n" + "\n".join(map(str, missing)))


def pool(dev):
    out = []
    for arm in POOL:
        for f in runs(dev, arm):
            d = json.load(open(f))
            out += [{**r, "arm": arm, "seed": d["meta"]["seed"]} for r in d["archive"]]
    return out


def subset(ds, net):
    return ds.subset((ds.screens.network == net).to_numpy())


def rates(pos, screens, mask=None):
    m = np.ones(len(screens), bool) if mask is None else mask
    c = screens.case.to_numpy() & m
    k = ~screens.case.to_numpy() & m
    return {"sensitivity": float(pos[c].mean()), "fpr": float(pos[k].mean()), "cancer_screens": int(c.sum()),
            "control_screens": int(k.sum()), "positives": int(pos[m].sum())}


def main():
    global OUT, DIRECTIONS
    if DRY:
        sys.path.insert(0, os.path.dirname(__file__))
        from run_search import development_set
        ds = development_set(load(), "LSS", pilot=True)
        ds.screens["network"] = np.where(ds.screens.pid.astype(int) % 2 == 0, "PA", "PB")
        DIRECTIONS, OUT = [("PA", "PB"), ("PB", "PA")], os.path.join(ROOT, "results_dryrun")
    else:
        check_complete()
        ds = load()
    os.makedirs(OUT, exist_ok=True)
    prsn = pd.read_parquet(os.path.join(RAW, "nlst_prsn.parquet"))[["pid", "gender", "age", "cigsmok"]]
    tests, primary = [], {"directions": {}}
    for dev, test in DIRECTIONS:
        ev_dev = Evaluator(subset(ds, dev))
        ref = ev_dev.metrics(V2022)
        sel = select(pool(dev), ref)
        t = subset(ds, test)
        ev_t = Evaluator(t)
        pos_new = ev_t.screen_positive(sel["rule"]) if sel else ev_t.screen_positive(V2022)
        pos_ref = ev_t.screen_positive(V2022)
        s = t.screens.copy()
        s["pos_new"], s["pos_ref"], s["direction"] = pos_new, pos_ref, f"{dev}->{test}"
        tests.append((t, s))
        primary["directions"][f"{dev}->{test}"] = {
            "selected": None if sel is None else {k: sel[k] for k in ("rule", "arm", "seed", "sensitivity", "fpr", "length")},
            "development_v2022": {"sensitivity": ref["sensitivity"], "fpr": ref["fpr"]},
            "test": compare(pos_new, pos_ref, s, seed=1)}
    S = pd.concat([s for _, s in tests], ignore_index=True)
    primary["pooled"] = compare(S.pos_new.to_numpy(), S.pos_ref.to_numpy(), S, seed=2)
    json.dump(primary, open(os.path.join(OUT, "primary.json"), "w"), indent=1, default=str)

    # secondary estimates
    sec = {}
    for lab, m in (("baseline", S.k == 0), ("follow-up", S.k > 0)):
        sub = S[m.to_numpy()]
        sec[lab] = compare(sub.pos_new.to_numpy(), sub.pos_ref.to_numpy(), sub, seed=3)
    n = len(S)
    for rule in ("new", "ref"):
        pos = S[f"pos_{rule}"].to_numpy(); case = S.case.to_numpy()
        sec[f"per_1000_{rule}"] = {"positives": 1000 * pos.mean(), "false_positives": 1000 * (pos & ~case).sum() / n,
                                   "detected_cancers": 1000 * (pos & case).sum() / n,
                                   "ppv": float((pos & case).sum() / max(pos.sum(), 1))}
    case = S.case.to_numpy()
    fp_avoided = int((S.pos_ref & ~S.case).sum() - (S.pos_new & ~S.case).sum())
    delayed = int((S.pos_ref & ~S.pos_new & S.case).sum()) - int((S.pos_new & ~S.pos_ref & S.case).sum())
    sec["false_positives_avoided"], sec["net_cancer_screens_lost"] = fp_avoided, delayed
    sec["false_positives_avoided_per_net_cancer_lost"] = fp_avoided / delayed if delayed > 0 else None
    disc = S[S.case & (S.pos_new != S.pos_ref)]
    sec["discordant_cancers"] = disc[["pid", "k", "direction", "pos_new", "pos_ref", "stage", "histology", "network"]].to_dict("records")
    nb = (~S.bac).to_numpy()
    sec["sensitivity_excluding_bac"] = {"new": rates(S.pos_new.to_numpy(), S, nb)["sensitivity"],
                                       "ref": rates(S.pos_ref.to_numpy(), S, nb)["sensitivity"]}
    S2 = S.merge(prsn, on="pid", how="left")
    groups = {"female": _num(S2.gender) == 2, "male": _num(S2.gender) == 1, "age_lt65": _num(S2.age) < 65,
              "age_ge65": _num(S2.age) >= 65, "current_smoker": _num(S2.cigsmok) == 1, "former_smoker": _num(S2.cigsmok) == 0}
    sec["subgroups"] = {g: {"new": rates(S2.pos_new.to_numpy(), S2, m.to_numpy()),
                            "ref": rates(S2.pos_ref.to_numpy(), S2, m.to_numpy())} for g, m in groups.items()}
    # robustness: diameters +/- 1 mm, and the perifissural rule of v2022 simulated (both rules)
    rng = np.random.default_rng(4)
    sec["perturbation"], sec["perifissural"] = {}, {}
    for (t, s), (dev, test) in zip(tests, DIRECTIONS):
        rule = primary["directions"][f"{dev}->{test}"]["selected"]
        rule = rule["rule"] if rule else V2022
        for delta in (-1.0, 1.0):
            t2 = type(t)(t.screens, t.nodules.assign(mean=t.nodules["mean"] + delta))
            e2 = Evaluator(t2)
            sec["perturbation"][f"{dev}->{test} {delta:+g} mm"] = {"new": rates(e2.screen_positive(rule), t.screens),
                                                                   "ref": rates(e2.screen_positive(V2022), t.screens)}
        e = Evaluator(t)
        ctrl_screen = ~t.screens.case.to_numpy()[t.nodules.row.to_numpy()]
        elig = (t.nodules.k.to_numpy() == 0) & (t.nodules.att.to_numpy() == SOLID) & (t.nodules["mean"].to_numpy() >= 6) \
            & (t.nodules["mean"].to_numpy() < 10) & ctrl_screen
        res = {"new": [], "ref": []}
        for _ in range(200):
            drop = elig & (rng.random(len(elig)) < 0.198)
            for lab, r in (("new", rule), ("ref", V2022)):
                npos = e.nodule_positive(r) & ~drop
                pos = (np.bincount(e.row[npos], minlength=e.n_screens) > 0) | e.x4
                res[lab].append(rates(pos, t.screens)["fpr"])
        sec["perifissural"][f"{dev}->{test}"] = {k: float(np.mean(v)) for k, v in res.items()}
    json.dump(sec, open(os.path.join(OUT, "secondary.json"), "w"), indent=1, default=str)

    # comparison of search arms: per run, the rule chosen by the primary selection rule, evaluated on the test network
    meth = {}
    for arm in POOL:
        meth[arm] = {}
        for dev, test in DIRECTIONS:
            ev_dev = Evaluator(subset(ds, dev)); ref = ev_dev.metrics(V2022)
            ev_t = Evaluator(subset(ds, test))
            vals = []
            for f in runs(dev, arm):
                d = json.load(open(f))
                sel = select([{**r} for r in d["archive"]], ref)
                m = ev_t.metrics(sel["rule"] if sel else V2022)
                vals.append({"seed": d["meta"]["seed"], "selected": sel is not None, "test_fpr": m["fpr"],
                             "test_sensitivity": m["sensitivity"], "length": complexity(sel["rule"]) if sel else 3,
                             "evaluated": d["meta"]["evaluated"], "seconds": d["meta"].get("seconds")})
            meth[arm][f"{dev}->{test}"] = vals
    json.dump(meth, open(os.path.join(OUT, "methods.json"), "w"), indent=1, default=str)

    # final rule: the same procedure on all participants
    ev_all = Evaluator(ds)
    sel = select(pool("ALL"), ev_all.metrics(V2022))
    json.dump({"selected": sel, "table": render(sel["rule"]) if sel else None}, open(os.path.join(OUT, "final_rule.json"), "w"),
              indent=1, default=str)

    p = primary["pooled"]
    print("pooled test: sensitivity %.1f%% vs %.1f%% (diff %.2f, %.2f to %.2f); FPR %.2f%% vs %.2f%% (diff %.2f, %.2f to %.2f); success %s"
          % (100 * p["sens_new"], 100 * p["sens_ref"], *(100 * np.array(p["sens_diff"])), 100 * p["fpr_new"], 100 * p["fpr_ref"],
             *(100 * np.array(p["fpr_diff"])), p["success"]))


if __name__ == "__main__":
    sys.exit(main())
