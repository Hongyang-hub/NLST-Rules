"""Figure of real CT examples of discordant test screens (descriptive, added after the primary evaluation).

    LUNA25_DIR=/path/to/luna25 python paper/make_fig_cases.py

LUNA25 (CC BY 4.0; Zenodo 10.5281/zenodo.14223624) holds CT images and nodule coordinates of NLST participants; it is
not part of this package. An annotated nodule counts as the decisive nodule of a screen when it lies in the same round
and within 3 mm of the slice that NLST recorded for that nodule (slice numbering from either end of the series).
Examples are chosen by a fixed procedure before any image is viewed: an example of Table 4 when it has such a match;
otherwise, within the same group, kind of nodule and histology class as that example, the lower median diameter (ties:
participant number); for the most advanced stage, the same rule among the highest stage. Writes results/figure_cases.json.
"""
import json, os, sys

import numpy as np
import pandas as pd
import SimpleITK as sitk
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Rectangle
import matplotlib.patheffects as pe

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path[:0] = [os.path.join(ROOT, "scripts"), os.path.join(ROOT, "src")]
import examples as X                                         # noqa: E402

LUNA = os.environ.get("LUNA25_DIR", "")
RES, FIG = os.path.join(ROOT, "results"), os.path.join(os.path.dirname(os.path.abspath(__file__)), "figures")
TOL_MM, WL, WW, FOV = 3.0, -600.0, 1500.0, 40.0
sitk.ProcessObject.SetGlobalWarningDisplay(False)
STAGE = {110: "IA", 120: "IB", 210: "IIA", 220: "IIB", 310: "IIIA", 320: "IIIB", 400: "IV"}
HIST = {8070: "Squamous-cell carcinoma", 8140: "Adenocarcinoma", 8250: "Bronchioloalveolar carcinoma", 8252: "Bronchioloalveolar carcinoma",
        8253: "Bronchioloalveolar carcinoma", 8254: "Bronchioloalveolar carcinoma", 8041: "Small-cell carcinoma", 8012: "Large-cell carcinoma"}


def series(pid, uid):
    p = os.path.join(LUNA, "dicom", str(pid), uid)
    if not os.path.isdir(p):
        return None
    r = sitk.ImageSeriesReader(); names = r.GetGDCMSeriesFileNames(p)
    if not names:
        return None
    r.SetFileNames(names)
    return sitk.DICOMOrient(r.Execute(), "LPS")


def discordant_with_slices():
    from nlst_rules.data import load
    D = X.discordant(); P = json.load(open(os.path.join(RES, "primary.json"))); ds = load()
    tests = {d: ds.subset((ds.screens.network == d.split("->")[1]).to_numpy()).screens.reset_index(drop=True) for d in P["directions"]}
    for x in D:
        x["pid"] = int(tests[x["direction"]].pid[x["row"]])
    c = pd.read_parquet(os.path.join(ROOT, "data", "raw", "idc_v25", "nlst_ctab.parquet"))
    for col in ["study_yr", "sct_ab_desc", "sct_long_dia", "sct_perp_dia", "sct_slice_num"]:
        c[col] = pd.to_numeric(c[col].astype(str).str.strip().replace("", np.nan), errors="coerce")
    c = c[c.sct_ab_desc == 51].assign(pid=lambda t: t.pid.astype(int))
    c["mean"] = (c.sct_long_dia + c.sct_perp_dia.fillna(c.sct_long_dia)) / 2
    out = pd.DataFrame(D)
    return out, c


def match(row, ann, c):
    """The annotation of this screen that lies on the slice NLST recorded for the decisive nodule, or None."""
    q = c[(c.pid == row.pid) & (c.study_yr == row.k) & np.isclose(c["mean"], row.diameter)]
    a = ann[(ann.pid == row.pid) & (ann.yr == row.k)]
    if q.empty or a.empty or np.isnan(q.sct_slice_num.iat[0]):
        return None
    sl, best = q.sct_slice_num.iat[0], None
    img = series(row.pid, a.SeriesInstanceUID.iat[0])
    if img is None:
        return None
    nz, dz = img.GetSize()[2], img.GetSpacing()[2]
    for _, n in a.iterrows():
        z = img.TransformPhysicalPointToContinuousIndex((n.CoordX, n.CoordY, n.CoordZ))[2]
        mm = min(abs(z + 1 - sl), abs(nz - z - sl)) * dz
        if mm <= TOL_MM and (best is None or mm < best["slice_mm"]):
            best = dict(nodule=n.NoduleID, uid=n.SeriesInstanceUID, xyz=[n.CoordX, n.CoordY, n.CoordZ], slice_mm=float(mm))
    return best


def median_first(xs, ann, c):
    """Lower median by (diameter, participant) among screens with a verified match, working outward only if a pick fails."""
    xs = xs.sort_values(["diameter", "pid"]).reset_index(drop=True)
    order = sorted(range(len(xs)), key=lambda i: (abs(i - (len(xs) - 1) // 2), i))
    for i in order:
        m = match(xs.iloc[i], ann, c)
        if m:
            return xs.iloc[i], m
    raise SystemExit("no match")


def choose():
    D, c = discordant_with_slices()
    ann = pd.read_csv(os.path.join(LUNA, "LUNA25_Public_Training_Development_Data.csv"))
    ann = ann.assign(pid=ann.PatientID.astype(int), yr=ann.StudyDate // 10000 - 1999)
    keys = set(zip(ann.pid, ann.yr))
    D = D[[k in keys for k in zip(D.pid, D.k)]]
    picks = []
    has_table4 = D[(D.pid == 214572) & (D.k == 0) & (D.group == "cancer_ref_only")]
    r = has_table4.iloc[0]; m = match(r, ann, c); assert m                         # example 1 of Table 4
    picks.append(("a", r, m))
    z = D[(D.group == "cancer_ref_only") & (D.status == "baseline") & (D.attenuation == "solid")]
    z = z[[match(x, ann, c) is not None for x in z.itertuples()]]
    r, m = median_first(z[z.stage == z.stage.max()], ann, c); picks.append(("b", r, m))     # most advanced stage with a match
    z = D[(D.group == "cancer_new_only") & (D.status == "growing") & (D.attenuation == "ground-glass") & D.bac]
    r, m = median_first(z, ann, c); picks.append(("c", r, m))
    z = D[(D.group == "control_ref_only") & (D.status == "baseline") & (D.attenuation == "solid")]
    r, m = median_first(z, ann, c); picks.append(("d", r, m))
    z = D[(D.group == "control_new_only") & (D.status == "new") & (D.attenuation == "ground-glass")]
    r, m = median_first(z, ann, c); picks.append(("e", r, m))
    out = []
    for lab, r, m in picks:
        out.append(dict(panel=lab, group=r.group, direction=r.direction, pid=int(r.pid), k=int(r.k), status=r.status, attenuation=r.attenuation,
                        diameter=float(r.diameter), n_nodules=int(r.n_nodules), lung_cancer=bool(r.lung_cancer),
                        days_to_diagnosis=None if pd.isna(r.days_to_diagnosis) else float(r.days_to_diagnosis),
                        stage=None if pd.isna(r.stage) else int(r.stage), histology=None if pd.isna(r.histology) else int(r.histology),
                        clause=r.clause, other_threshold=None if pd.isna(r.other_threshold) else float(r.other_threshold), **m))
    json.dump(out, open(os.path.join(RES, "figure_cases.json"), "w"), indent=1, default=str)
    return out


def view(img, xyz):
    """Axial slice through the nodule, windowed; pixel size kept; returns slice, in-plane centre, spacing."""
    i, j, k = img.TransformPhysicalPointToContinuousIndex(xyz)
    a = sitk.GetArrayViewFromImage(img)[int(round(k))].astype(float)
    return np.clip((a - (WL - WW / 2)) / WW, 0, 1), i, j, img.GetSpacing()


def main():
    p = os.path.join(RES, "figure_cases.json")
    cases = json.load(open(p)) if os.path.exists(p) and not os.environ.get("REFRESH") else choose()
    for f in font_manager.findSystemFonts(fontpaths=[os.path.expanduser("~/.local/share/fonts")]):
        font_manager.fontManager.addfont(f)
    plt.rcParams.update({"font.family": "Times New Roman", "font.size": 9, "pdf.fonttype": 42})
    n, h = len(cases), 1.52
    fig = plt.figure(figsize=(7.0, h * n + 0.2))
    gs = fig.add_gridspec(n, 3, width_ratios=[1, 1, 2.45], left=0.004, right=0.998, top=1 - 0.2 / (h * n + 0.2), bottom=0.004, wspace=0.025, hspace=0.03)
    Y = "#ffd21f"
    for r, c in enumerate(cases):
        img = series(c["pid"], c["uid"]); a, i, j, sp = view(img, c["xyz"])
        cx, cy = i * sp[0], j * sp[1]
        ext = (0, a.shape[1] * sp[0], a.shape[0] * sp[1], 0)
        ax = fig.add_subplot(gs[r, 0]); ax.imshow(a, cmap="gray", vmin=0, vmax=1, interpolation="bilinear", extent=ext)
        ax.add_patch(Rectangle((cx - FOV / 2, cy - FOV / 2), FOV, FOV, fill=False, ec=Y, lw=0.9))
        ax.set_xticks([]); ax.set_yticks([]); [q.set_visible(False) for q in ax.spines.values()]
        ax.text(0.03, 0.97, f"({c['panel']})", transform=ax.transAxes, color="white", va="top", fontweight="bold", fontsize=9.5)
        if r == 0:
            ax.set_title("Axial slice", fontsize=9, pad=2.5)
        ax = fig.add_subplot(gs[r, 1]); ax.imshow(a, cmap="gray", vmin=0, vmax=1, interpolation="bicubic", extent=ext)
        ax.set_xlim(cx - FOV / 2, cx + FOV / 2); ax.set_ylim(cy + FOV / 2, cy - FOV / 2)
        ax.set_xticks([]); ax.set_yticks([]); [q.set_visible(False) for q in ax.spines.values()]
        x0, y0 = cx + FOV / 2 - 13, cy + FOV / 2 - 3
        ax.plot([x0, x0 + 10], [y0, y0], color="white", lw=1.4, solid_capstyle="butt", path_effects=[pe.withStroke(linewidth=2.4, foreground="black")])
        ax.text(x0 + 5, y0 - 1, "10 mm", color="white", ha="center", va="bottom", fontsize=7.5, path_effects=[pe.withStroke(linewidth=1.6, foreground="black")])
        off = max(c["diameter"] / 2 + 2.5, 5.0)
        ax.annotate("", xy=(cx - off * 0.71, cy - off * 0.71), xytext=(cx - off * 0.71 - 6, cy - off * 0.71 - 6), arrowprops=dict(arrowstyle="-|>", color=Y, lw=1.1, shrinkA=0, shrinkB=0, mutation_scale=8))
        if r == 0:
            ax.set_title("40-mm view", fontsize=9, pad=2.5)
        ax = fig.add_subplot(gs[r, 2]); ax.axis("off")
        by_ref = c["group"].endswith("ref_only")
        rnd = ["Baseline", "First follow-up", "Second follow-up"][c["k"]]
        status = "" if c["status"] == "baseline" else c["status"] + " "
        cl, th = c["clause"]["min_size"], c["other_threshold"]
        neg = f"negative (below {th:g} mm)" if th else "negative (not covered at any size)"
        pos = f"positive (\u2265{cl:g} mm)"
        lines = [(f"{rnd} screen: {status}{c['attenuation']} nodule, {c['diameter']:g} mm", "bold"),
                 (f"Lung-RADS v2022: {pos if by_ref else neg}", "normal"), (f"Selected rule: {neg if by_ref else pos}", "normal")]
        if c["lung_cancer"]:
            lines += [(f"{HIST.get(c['histology'], str(c['histology']))}, stage {STAGE[c['stage']]},", "normal"),
                      (f"diagnosed {c['days_to_diagnosis']:.0f} days after the screen", "normal")]
        else:
            lines.append(("No lung cancer diagnosed during the trial", "normal"))
        top = 0.5 + (len(lines) - 1) * 0.085
        for q, (t, w) in enumerate(lines):
            ax.text(0.03, top - q * 0.17, t, transform=ax.transAxes, fontweight=w, fontsize=9, va="center")
    fig.savefig(os.path.join(FIG, "fig_cases.pdf"), dpi=300); plt.close(fig)
    print("cases figure written")


if __name__ == "__main__":
    main()
