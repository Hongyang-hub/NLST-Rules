"""Result figures beyond those of make_results.py, from results/*.json and the run archives.

    python paper/make_figures.py

Main text: fig_rules.pdf (thresholds by nodule category), fig_forest.pdf (differences with 95% CIs), fig_discordant.pdf.
Supplement: figS_per1000.pdf (rates per 1,000 screens and PPV by category), figS_convergence.pdf (search progress).
"""
import glob, json, os, sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
from nlst_rules.rules import load_rule                                  # noqa: E402

for f in glob.glob(os.path.expanduser("~/.local/share/fonts/times-new-roman/*.[tT][tT][fF]")):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman"], "mathtext.fontset": "stix",
                     "pdf.fonttype": 42, "font.size": 9})
RES, FIG = os.path.join(ROOT, "results"), os.path.join(os.path.dirname(__file__), "figures")
P = json.load(open(os.path.join(RES, "primary.json")))
SEC = json.load(open(os.path.join(RES, "secondary.json")))
PR = json.load(open(os.path.join(RES, "protocol.json")))
FINAL = json.load(open(os.path.join(RES, "final_rule.json")))["selected"]["rule"]
V2022 = load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v2022.json"))
BLUE, GREY, RED = "#1f5fa8", "#555555", "#b2182b"


# --- thresholds by nodule category ---------------------------------------------------------------------------------
CATEGORIES = [  # label, round, nodule status ('new' or 'growing' at follow-up; every baseline nodule is new), attenuation
    ("Baseline, solid", "baseline", "new", "solid"), ("Baseline, part-solid", "baseline", "new", "part_solid"),
    ("Baseline, ground-glass", "baseline", "new", "ggo"),
    ("Follow-up, new solid", "followup", "new", "solid"), ("Follow-up, growing solid", "followup", "growing", "solid"),
    ("Follow-up, new part-solid", "followup", "new", "part_solid"), ("Follow-up, growing part-solid", "followup", "growing", "part_solid"),
    ("Follow-up, new ground-glass", "followup", "new", "ggo"), ("Follow-up, growing ground-glass", "followup", "growing", "ggo")]
COVERS = {"all": {"new", "growing"}, "new": {"new"}, "growing": {"growing"}, "new_or_growing": {"new", "growing"}}


def threshold(rule, rnd, status, att):
    """Smallest diameter at which a nodule of this category is positive (no restricting conditions), or None."""
    ts = [c["min_size"] for c in rule["clauses"] if c["round"] in (rnd, "any") and status in COVERS[c["status"]]
          and att in c["attenuation"] and not any(c.get(f) for f in ("spiculated", "upper_lobe", "emphysema", "min_nodules"))]
    return min(ts) if ts else None


def fig_rules():
    rules = [("Lung-RADS v2022", V2022, "black", "s"), ("Selected on LSS", P["directions"]["LSS->ACRIN"]["selected"]["rule"], BLUE, "o"),
             ("Selected on ACRIN", P["directions"]["ACRIN->LSS"]["selected"]["rule"], "#4daf4a", "^"),
             ("Final rule (all participants)", FINAL, RED, "D")]
    fig, ax = plt.subplots(figsize=(6.6, 4.0))
    never = 33
    for k, (lab, rule, col, mk) in enumerate(rules):
        off = (k - 1.5) * 0.17
        for y, (_, rnd, st, att) in enumerate(CATEGORIES):
            t = threshold(rule, rnd, st, att)
            ax.scatter(never if t is None else t, y + off, marker="x" if t is None else mk, color=col, s=26 if t is None else 22,
                       label=lab if y == 0 else None, zorder=3)
    ax.axvspan(31.5, 34.5, color="0.93", zorder=0)
    ax.set_yticks(range(len(CATEGORIES))); ax.set_yticklabels([c[0] for c in CATEGORIES]); ax.invert_yaxis()
    ax.axhline(2.5, color="0.7", lw=0.6)
    ax.set_xticks([4, 6, 8, 10, 15, 20, 25, 30, never]); ax.set_xticklabels(["4", "6", "8", "10", "15", "20", "25", "30", "never"])
    ax.set_xlim(3, 34.5); ax.set_xlabel("Smallest mean diameter called positive (mm)")
    ax.grid(axis="x", color="0.9", lw=0.5)
    ax.legend(fontsize=7.5, loc="lower center", bbox_to_anchor=(0.45, 1.0), ncol=2, frameon=False)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_rules.pdf")); plt.close(fig)


# --- forest plot ----------------------------------------------------------------------------------------------------
def subgroup_cis():
    import pandas as pd
    from protocol_analyses import pooled, stack
    from nlst_rules.data import load, RAW, _num
    from nlst_rules.evaluate import compare
    ds = load()
    S = stack(pooled(ds))
    p = pd.read_parquet(os.path.join(RAW, "nlst_prsn.parquet"))[["pid", "gender", "age", "cigsmok"]]
    p["pid"] = p.pid.astype(S.pid.dtype)
    S = S.merge(p, on="pid", how="left")
    groups = [("Women", _num(S.gender) == 2), ("Men", _num(S.gender) == 1), ("Age < 65 years", _num(S.age) < 65),
              ("Age $\\geq$ 65 years", _num(S.age) >= 65), ("Current smokers", _num(S.cigsmok) == 1), ("Former smokers", _num(S.cigsmok) == 0)]
    out = []
    for lab, m in groups:
        sub = S[m.to_numpy()].reset_index(drop=True)
        r = compare(sub.pos_new.to_numpy(), sub.pos_ref.to_numpy(), sub, n_boot=2000, seed=21)
        out.append((lab, r["sens_diff"], r["fpr_diff"]))
    json.dump({lab: {"sens_diff": s, "fpr_diff": d} for lab, s, d in out}, open(os.path.join(RES, "subgroup_ci.json"), "w"), indent=1, default=float)
    return out


def fig_forest():
    sa = PR["sensitivity_analyses"]
    rows = [("Primary analysis", None, None),
            ("Pooled test screens", P["pooled"]["sens_diff"], P["pooled"]["fpr_diff"]),
            ("LSS $\\rightarrow$ ACRIN", P["directions"]["LSS->ACRIN"]["test"]["sens_diff"], P["directions"]["LSS->ACRIN"]["test"]["fpr_diff"]),
            ("ACRIN $\\rightarrow$ LSS", P["directions"]["ACRIN->LSS"]["test"]["sens_diff"], P["directions"]["ACRIN->LSS"]["test"]["fpr_diff"]),
            ("Screening round", None, None),
            ("Baseline screens", SEC["baseline"]["sens_diff"], SEC["baseline"]["fpr_diff"]),
            ("Follow-up screens", SEC["follow-up"]["sens_diff"], SEC["follow-up"]["fpr_diff"]),
            ("Sensitivity analyses", None, None),
            ("Missing comparison as new", sa["missing_comparison_as_new"]["sens_diff"], sa["missing_comparison_as_new"]["fpr_diff"]),
            ("Short follow-up excluded", sa["short_followup_controls_excluded"]["sens_diff"], sa["short_followup_controls_excluded"]["fpr_diff"]),
            ("2-year outcome window", sa["two_year_window"]["sens_diff"], sa["two_year_window"]["fpr_diff"]),
            ("GEE", sa["gee"]["sensitivity"], sa["gee"]["fpr"]),
            ("Cancers and categories", None, None),
            ("Clinically significant cancers", PR["clinically_significant"]["sens_diff"], None),
            ("Category 4A or higher", PR["at_4A_or_higher"]["sens_diff"], PR["at_4A_or_higher"]["fpr_diff"]),
            ("Subgroups", None, None)] + subgroup_cis()
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 5.6), sharey=True, gridspec_kw={"width_ratios": [1.15, 1]})
    ys = np.arange(len(rows))
    for ax, idx, title, xlim in ((axes[0], 1, "Sensitivity difference (percentage points)", (-11, 9)),
                                 (axes[1], 2, "False-positive-rate difference (percentage points)", (-6, 0.6))):
        for y, row in zip(ys, rows):
            v = row[idx]
            if v is None:
                continue
            est, lo, hi = (100 * np.asarray(v)).tolist()
            col = BLUE if row[0] == "Pooled test screens" else ("0.25")
            ax.plot([lo, hi], [y, y], color=col, lw=1.2)
            ax.scatter(est, y, marker="D" if row[0] == "Pooled test screens" else "s", color=col, s=22 if row[0] == "Pooled test screens" else 14, zorder=3)
        ax.axvline(0, color="black", lw=0.7)
        if idx == 1:
            ax.axvline(-3, color=RED, lw=0.8, ls="--")
            ax.text(-3.2, -1.1, "Margin $-3$", color=RED, fontsize=7, ha="right", va="center")
        ax.set_xlim(*xlim); ax.set_xlabel(title, fontsize=8); ax.grid(axis="x", color="0.92", lw=0.5)
    axes[0].set_yticks(ys)
    axes[0].set_yticklabels([r[0] for r in rows])
    for lab, y in zip(axes[0].get_yticklabels(), ys):
        if rows[y][1] is None and rows[y][2] is None:
            lab.set_fontweight("bold")
    axes[0].set_ylim(len(rows) - 0.4, -1.7)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_forest.pdf")); plt.close(fig)


# --- discordant cancers ---------------------------------------------------------------------------------------------
def fig_discordant():
    d = SEC["discordant_cancers"]
    def hist(h):
        h = int(h or 0)
        if 8250 <= h <= 8254: return "BAC"
        if 8140 <= h <= 8575: return "Other\nadeno-\ncarcinoma"
        return {8070: "Squamous-\ncell", 8071: "Squamous-\ncell", 8072: "Squamous-\ncell", 8041: "Small-\ncell", 8012: "Large-\ncell", 8046: "NSCLC,\nNOS"}.get(h, "Other")
    def stage(s):
        s = int(s or 0)
        return {110: "IA", 120: "IB", 210: "II", 220: "II", 310: "III", 320: "III", 400: "IV"}.get(s, "Unknown")
    groups = {"Lung-RADS v2022 only": [x for x in d if x["pos_ref"] and not x["pos_new"]],
              "Selected rules only": [x for x in d if x["pos_new"] and not x["pos_ref"]]}
    hcats = ["BAC", "Other\nadeno-\ncarcinoma", "Squamous-\ncell", "Small-\ncell", "Large-\ncell", "NSCLC,\nNOS"]
    scats = ["IA", "IB", "II", "III", "IV"]
    fig, axes = plt.subplots(1, 3, figsize=(7.4, 3.0), gridspec_kw={"width_ratios": [1.7, 1.1, 0.7]})
    w = 0.38
    for k, (lab, xs) in enumerate(groups.items()):
        col = GREY if k == 0 else BLUE
        axes[0].bar(np.arange(len(hcats)) + (k - 0.5) * w, [sum(hist(x["histology"]) == c for x in xs) for c in hcats], w, color=col, label=f"{lab} (n = {len(xs)})")
        axes[1].bar(np.arange(len(scats)) + (k - 0.5) * w, [sum(stage(x["stage"]) == c for x in xs) for c in scats], w, color=col)
        axes[2].bar(np.arange(2) + (k - 0.5) * w, [sum(x["k"] == 0 for x in xs), sum(x["k"] > 0 for x in xs)], w, color=col)
    axes[0].set_xticks(range(len(hcats))); axes[0].set_xticklabels(hcats, fontsize=7, rotation=0)
    axes[1].set_xticks(range(len(scats))); axes[1].set_xticklabels(scats)
    axes[2].set_xticks([0, 1]); axes[2].set_xticklabels(["Baseline", "Follow-up"], fontsize=8)
    for ax, t in zip(axes, ("Histology", "Stage", "Screening round")):
        ax.set_title(t, fontsize=9); ax.spines[["top", "right"]].set_visible(False)
    axes[0].set_ylabel("Cancer screens"); axes[0].legend(fontsize=7, frameon=False, loc="upper right")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "fig_discordant.pdf")); plt.close(fig)


# --- supplement: per 1,000 screens and PPV by category --------------------------------------------------------------
def figS_per1000():
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8))
    labs = ["Positive screens", "False positives", "Detected cancers $\\times$ 10"]
    new = [SEC["per_1000_new"]["positives"], SEC["per_1000_new"]["false_positives"], 10 * SEC["per_1000_new"]["detected_cancers"]]
    ref = [SEC["per_1000_ref"]["positives"], SEC["per_1000_ref"]["false_positives"], 10 * SEC["per_1000_ref"]["detected_cancers"]]
    x, w = np.arange(3), 0.38
    axes[0].bar(x - w / 2, ref, w, color=GREY, label="Lung-RADS v2022"); axes[0].bar(x + w / 2, new, w, color=BLUE, label="Selected rules")
    axes[0].set_xticks(x); axes[0].set_xticklabels(labs, fontsize=8); axes[0].set_ylabel("Per 1,000 screens")
    axes[0].legend(fontsize=7, frameon=False)
    cats = ["3", "4A", "4B", "4X"]
    for k, (name, col) in enumerate((("ref", GREY), ("new", BLUE))):
        v = [100 * (PR["ppv_by_category"][name][c]["ppv"] or 0) for c in cats]
        axes[1].bar(np.arange(4) + (k - 0.5) * w, v, w, color=col)
    axes[1].set_xticks(range(4)); axes[1].set_xticklabels([f"Category {c}" for c in cats], fontsize=8)
    axes[1].set_ylabel("Positive predictive value (%)")
    for ax in axes:
        ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "figS_per1000.pdf")); plt.close(fig)


# --- supplement: search progress on the development network -------------------------------------------------------
def figS_convergence():
    from nlst_rules.data import load
    from nlst_rules.rules import Evaluator
    from evaluate import subset, runs
    from nlst_rules.evaluate import select
    ds = load()
    labels = {"nsga2_gp": "NSGA-II", "mapelites_gp": "MAP-Elites", "random": "Random search"}
    colors = {"nsga2_gp": BLUE, "mapelites_gp": "#4daf4a", "random": GREY}
    checkpoints = np.unique(np.round(np.logspace(np.log10(100), np.log10(5000), 25)).astype(int))
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.2), sharey=False)
    for ax, dev in zip(axes, ("LSS", "ACRIN")):
        ref = Evaluator(subset(ds, dev)).metrics(load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v2022.json")))
        target = ref["sensitivity"] + 0.01
        for arm in labels:
            curves = []
            for f in runs(dev, arm):
                arch = sorted(json.load(open(f))["archive"], key=lambda r: r["eval"])
                sens = np.array([r["sensitivity"] for r in arch]); fpr = np.array([r["fpr"] for r in arch])
                feas = np.where(sens >= target - 1e-12, fpr, np.inf)
                best = np.minimum.accumulate(feas)
                curves.append([100 * best[min(c, len(best)) - 1] for c in checkpoints])
            c = np.array(curves)
            ax.plot(checkpoints, np.median(c, 0), color=colors[arm], label=labels[arm])
            ax.fill_between(checkpoints, np.percentile(c, 25, 0), np.percentile(c, 75, 0), color=colors[arm], alpha=0.15, lw=0)
        for arm, ls in (("retuned", ":"), ("greedy", "-.")):
            d = json.load(open(runs(dev, arm)[0]))
            feas = [r["fpr"] for r in d["archive"] if r["sensitivity"] >= target - 1e-12]
            ax.axhline(100 * min(feas), color="black", ls=ls, lw=0.9, label="Re-tuned Lung-RADS" if arm == "retuned" else "Greedy rule learner")
        ax.axhline(100 * ref["fpr"], color=RED, lw=0.8, label="Lung-RADS v2022")
        ax.set_xscale("log"); ax.set_xlabel("Distinct rules evaluated"); ax.set_title(f"Development network {dev}", fontsize=9)
        ax.set_ylabel("Lowest FPR meeting the selection constraint (%)", fontsize=8)
        ax.spines[["top", "right"]].set_visible(False)
    h, l = axes[0].get_legend_handles_labels()
    fig.legend(h, l, fontsize=7, frameon=False, loc="lower center", ncol=len(l))
    fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(os.path.join(FIG, "figS_convergence.pdf")); plt.close(fig)


if __name__ == "__main__":
    fig_rules(); fig_discordant(); figS_per1000(); fig_forest(); figS_convergence()
    print("figures written")
