"""Tables and figures of the paper from results/*.json (written by scripts/evaluate.py).

    python paper/make_results.py              # formal results (results/)
    python paper/make_results.py --dry-run    # code check on results_dryrun/ (pilot subsample only)
"""
import json, os, sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import glob

# Figures in Times New Roman, embedded as TrueType
for f in glob.glob(os.path.expanduser("~/.local/share/fonts/times-new-roman/*.[tT][tT][fF]")):
    font_manager.fontManager.addfont(f)
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman"], "mathtext.fontset": "stix",
                     "pdf.fonttype": 42, "ps.fonttype": 42})

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))
from nlst_rules.data import load                                   # noqa: E402
from nlst_rules.rules import Evaluator, load_rule, render          # noqa: E402

DRY = "--dry-run" in sys.argv
RES = os.path.join(ROOT, "results_dryrun" if DRY else "results")
TAB = os.path.join(os.path.dirname(__file__), "tables_dryrun" if DRY else "tables")
FIG = os.path.join(os.path.dirname(__file__), "figures_dryrun" if DRY else "figures")
ARM_LABEL = {
    "retuned": "Re-tuned Lung-RADS", "greedy": "Greedy rule learner", "random": "Random search",
    "nsga2_gp": "NSGA-II", "mapelites_gp": "MAP-Elites"}
pct = lambda x: f"{100 * x:.1f}"
ci = lambda t: f"{100 * t[0]:+.2f} ({100 * t[1]:+.2f} to {100 * t[2]:+.2f})".replace("-", "$-$")


def write(name, text):
    os.makedirs(TAB, exist_ok=True)
    open(os.path.join(TAB, name), "w").write(text)


def table_primary(P, sec):
    rows = []
    def row(label, c):
        rows.append(f"{label} & {pct(c['sens_new'])} & {pct(c['sens_ref'])} & {ci(c['sens_diff'])} & "
                    f"{100 * c['fpr_new']:.2f} & {100 * c['fpr_ref']:.2f} & {ci(c['fpr_diff'])} \\\\")
    row("Pooled test screens (co-primary)", P["pooled"])
    for d, v in P["directions"].items():
        row(f"\\quad {d.replace('->', ' $\\rightarrow$ ')}", v["test"])
    row("\\quad Baseline screens", sec["baseline"])
    row("\\quad Follow-up screens", sec["follow-up"])
    write("table_primary.tex", r"""\begin{table}[!t]
\centering\small
\caption{Selected rules versus Lung-RADS v2022 on the test screens of internal--external validation. Sensitivity and false-positive rate (FPR) in \%; differences in percentage points with 95\% confidence intervals (Tango score interval for sensitivity, participant bootstrap for FPR). Network rows give the network used for derivation $\rightarrow$ the test network.}
\label{tab:primary}
\setlength{\tabcolsep}{2.5pt}
\begin{tabular}{lrrlrrl}
\toprule
 & \multicolumn{3}{c}{Sensitivity} & \multicolumn{3}{c}{False-positive rate} \\
\cmidrule(lr){2-4}\cmidrule(lr){5-7}
Test screens & Rule & v2022 & Difference & Rule & v2022 & Difference \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")


def table_rules(P, final):
    ROUND = {"baseline": "Baseline", "followup": "Follow-up", "any": "Any"}
    def rows(rule):
        out = []
        for l in render(rule).splitlines()[2:]:
            cells = [c.strip().replace(">=", "$\\geq$") for c in l.strip("|").split("|")]
            cells[0] = ROUND.get(cells[0], cells[0])
            out.append(["--" if c == "-" else c for c in cells])
        return out
    v2022 = load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v2022.json"))
    blocks = [("Lung-RADS v2022 (category 3 or higher, as implementable on NLST)", rows(v2022))]
    for d, v in P["directions"].items():
        if v["selected"]:
            blocks.append((f"Selected on {d.split('->')[0]} (arm: {ARM_LABEL.get(v['selected']['arm'], v['selected']['arm'])})", rows(v["selected"]["rule"])))
    if final.get("selected"):
        blocks.append((f"Final rule, selected on all participants (arm: {ARM_LABEL.get(final['selected']['arm'], final['selected']['arm'])})", rows(final["selected"]["rule"])))
    conditions = any(r[4] != "--" for _, rs in blocks for r in rs)
    ncol = 5 if conditions else 4
    parts = [f"\\multicolumn{{{ncol}}}{{l}}{{\\textit{{{t}}}}} \\\\\n" + "\n".join(" & ".join(r[:ncol]) + " \\\\" for r in rs) for t, rs in blocks]
    header = "Round & Nodule & Attenuation & Size" + (" & Additional condition" if conditions else "")
    write("table_rules.tex", r"""\begin{table}[!t]
\centering\small
\caption{Positive-screen rules. A nodule is positive (category 3 or higher) when it meets any row; a screen is positive when any nodule is positive or when it is in the fixed 4X layer. At baseline, every nodule counts as new. Size is the mean of the long and perpendicular diameters.}
\label{tab:rules}
\begin{tabular}{""" + "l" * ncol + r"""}
\toprule
""" + header + r""" \\
\midrule
""" + "\n\\midrule\n".join(parts) + r"""
\bottomrule
\end{tabular}
\end{table}
""")


def table_methods(M):
    rows = []
    for arm, label in ARM_LABEL.items():
        if arm not in M:
            continue
        vals = [v for d in M[arm].values() for v in d]
        if not vals:
            continue
        fpr = np.array([v["test_fpr"] for v in vals]); sens = np.array([v["test_sensitivity"] for v in vals])

        spread = (f"{100*np.median(fpr):.2f} ({100*np.percentile(fpr,25):.2f}--{100*np.percentile(fpr,75):.2f})" if len(vals) > 2
                  else ", ".join(f"{100*x:.2f}" for x in fpr) + "$^a$")
        rows.append(f"{label} & {len(vals)} & {spread} & "
                    f"{100*np.median(sens):.1f} \\\\")
    write("table_methods.tex", r"""\begin{table}[!t]
\centering\small
\caption{Search arms. For each run, the rule chosen by the prespecified selection criterion from that run alone, evaluated on the test network; both directions. Test false-positive rate (FPR) and median sensitivity in \%. Every run found a rule meeting the selection constraint. Stochastic arms: 20 runs of 5,000 distinct rules per direction; re-tuned Lung-RADS: exhaustive grid of 364,481 rules. IQR, interquartile range. $^a$Deterministic arms, one rule per direction: false-positive rates of both rules shown, sensitivity as their mean.}
\label{tab:methods}
\setlength{\tabcolsep}{3.5pt}
\begin{tabular}{lrlr}
\toprule
Arm & Runs & FPR, median (IQR) & Sensitivity \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")


def figure_methods(M):
    """Test false-positive rate and sensitivity of the rule chosen from each run alone, by direction. Vertical jitter only."""
    order = [a for a in ("retuned", "greedy", "nsga2_gp", "mapelites_gp", "random") if a in M and any(M[a].values())]
    P = json.load(open(os.path.join(RES, "primary.json")))["directions"]
    DIRS = (("LSS->ACRIN", "#1f5fa8", -0.17, "Derived on LSS, tested on ACRIN"), ("ACRIN->LSS", "#2e7d3c", 0.17, "Derived on ACRIN, tested on LSS"))
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.55), sharey=True)
    rng = np.random.default_rng(0)
    panels = ((axes[0], "test_fpr", "fpr_ref", "False-positive rate on the test network (%)", "a"),
              (axes[1], "test_sensitivity", "sens_ref", "Sensitivity on the test network (%)", "b"))
    for ax, key, ref_key, label, letter in panels:
        for i in range(len(order)):
            if i % 2 == 0:
                ax.axhspan(i - 0.5, i + 0.5, color="#f5f6f8", zorder=0, lw=0)
        for d, col, off, _ in DIRS:
            ax.axvline(100 * P[d]["test"][ref_key], color=col, ls=(0, (3, 2)), lw=0.9, zorder=1)
            for i, a in enumerate(order):
                v = np.array([100 * r[key] for r in M[a][d]])
                y = i + off
                if len(v) == 1:                               # deterministic arm: one rule per direction
                    ax.scatter(v, [y], marker="D", s=30, color=col, edgecolor="white", linewidth=0.5, zorder=4)
                    continue
                ax.scatter(v, y + rng.uniform(-0.1, 0.1, len(v)), s=9, color=col, alpha=0.32, linewidth=0, zorder=2)
                q1, med, q3 = np.percentile(v, [25, 50, 75])
                ax.plot([q1, q3], [y, y], color=col, lw=2.4, solid_capstyle="butt", zorder=3)
                ax.plot([med, med], [y - 0.13, y + 0.13], color=col, lw=1.8, zorder=4)
        ax.set_xlabel(label, fontsize=9); ax.tick_params(axis="x", labelsize=8); ax.tick_params(axis="y", length=0)
        ax.spines[["top", "right", "left"]].set_visible(False); ax.grid(axis="x", color="0.9", lw=0.5); ax.set_axisbelow(True)
        ax.text(0.0, 1.015, letter, transform=ax.transAxes, fontweight="bold", fontsize=10, va="bottom")
    axes[0].set_yticks(range(len(order))); axes[0].set_yticklabels([ARM_LABEL[a] for a in order], fontsize=9)
    axes[0].set_ylim(len(order) - 0.5, -0.5)
    from matplotlib.lines import Line2D
    handles = [Line2D([], [], color=c, lw=2.4, label=t) for _, c, _, t in DIRS]
    handles += [Line2D([], [], color="0.35", lw=2.4, marker="|", ms=7, mew=1.8, label="Interquartile range and median of the runs"),
                Line2D([], [], color="0.35", marker="o", ms=3.5, alpha=0.5, ls="", label="Single run"),
                Line2D([], [], color="0.35", marker="D", ms=5, ls="", label="Deterministic arm"),
                Line2D([], [], color="0.35", ls=(0, (3, 2)), lw=0.9, label="Lung-RADS v2022 on that test network")]
    fig.legend(handles=handles, ncol=3, fontsize=8, frameon=False, loc="upper center", bbox_to_anchor=(0.54, 1.0), columnspacing=1.2, handletextpad=0.5)
    fig.tight_layout(rect=(0, 0, 1, 0.885), w_pad=1.5); os.makedirs(FIG, exist_ok=True)
    fig.savefig(os.path.join(FIG, "fig_methods.pdf")); plt.close(fig)


def figure_tradeoff(P):
    """Per test network: non-dominated development rules of the candidate pool, the selected rule and the comparators."""
    sys.path.insert(0, os.path.join(ROOT, "scripts"))
    from evaluate import pool, subset, V2022
    from nlst_rules.search import nondominated, key
    v10 = load_rule(os.path.join(ROOT, "rules", "comparators", "lungrads_v10.json"))
    ds = load()
    fig, axes = plt.subplots(1, 2, figsize=(9, 3.8), sharey=True)
    for ax, (d, v) in zip(axes, P["directions"].items()):
        dev, test = d.split("->")
        uniq = {key(r["rule"]): r for r in pool(dev)}
        front = nondominated(list(uniq.values()))
        ev = Evaluator(subset(ds, test))
        pts = np.array([[ev.metrics(r["rule"])["fpr"], ev.metrics(r["rule"])["sensitivity"]] for r in front])
        ax.scatter(100 * pts[:, 0], 100 * pts[:, 1], s=6, color="0.75", label="Non-dominated development rules")
        for rule, mk, lab in ((V2022, "s", "Lung-RADS v2022"), (v10, "^", "Lung-RADS v1.0")):
            m = ev.metrics(rule); ax.scatter(100 * m["fpr"], 100 * m["sensitivity"], marker=mk, color="black", s=40, label=lab, zorder=3)
        t = v["test"]
        ax.scatter(100 * t["fpr_new"], 100 * t["sens_new"], color="#1f5fa8", s=60, label="Rule selected on the development network", zorder=4)
        ax.set_xlim(0, 20); ax.set_ylim(50, 100)
        ax.set_title(f"Derived on {dev}, tested on {test}", fontsize=9); ax.set_xlabel("False-positive rate (%)")
    axes[0].set_ylabel("Sensitivity (%)"); axes[1].legend(fontsize=7, loc="lower right")
    fig.tight_layout(); os.makedirs(FIG, exist_ok=True); fig.savefig(os.path.join(FIG, "fig_tradeoff.pdf")); plt.close(fig)


def numbers(P, sec, M, final):
    out = {"pooled": P["pooled"], "baseline": sec["baseline"], "follow-up": sec["follow-up"],
           "per_1000_new": sec["per_1000_new"], "per_1000_ref": sec["per_1000_ref"],
           "fp_avoided": sec["false_positives_avoided"], "net_cancers_lost": sec["net_cancer_screens_lost"],
           "fp_avoided_per_cancer": sec["false_positives_avoided_per_net_cancer_lost"],
           "sens_excl_bac": sec["sensitivity_excluding_bac"], "perifissural": sec["perifissural"],
           "final_arm": (final.get("selected") or {}).get("arm")}
    json.dump(out, open(os.path.join(RES, "numbers.json"), "w"), indent=1, default=str)


def table_data():
    import pandas as pd
    from nlst_rules.data import RAW, _num
    s = load().screens
    p = pd.read_parquet(os.path.join(RAW, "nlst_prsn.parquet"))
    p = p[p.pid.isin(set(s.pid))]
    p = p.assign(network=np.where(p.pid.astype(str).str[0] == "1", "LSS", "ACRIN"), age_n=_num(p.age), sex=_num(p.gender), smk=_num(p.cigsmok))
    rows = []
    for net in ("LSS", "ACRIN", "Total"):
        x = s if net == "Total" else s[s.network == net]
        q = p if net == "Total" else p[p.network == net]
        a = q.age_n.quantile([0.25, 0.5, 0.75]).to_numpy()
        rows.append(f"{net} & {x.pid.nunique():,} & {a[1]:.0f} ({a[0]:.0f}--{a[2]:.0f}) & {100 * (q.sex == 2).mean():.1f} & {100 * (q.smk == 1).mean():.1f} & "
                    f"{len(x):,} & {int((x.k == 0).sum()):,} & {int((x.k > 0).sum()):,} & {int(x.case.sum())} & {int(x.bac.sum())} \\\\")
    write("table_data.tex", r"""\begin{table}[!t]
\centering\small
\caption{Participants and screens of the NLST CT arm by screening network. Age at randomization, median (interquartile range). Cancer screens: screens followed by a lung cancer diagnosis before the next completed screen or within 365 days (one per cancer); BAC, bronchioloalveolar carcinoma.}
\label{tab:data}
\setlength{\tabcolsep}{4pt}
\begin{tabular}{lrrrrrrrrr}
\toprule
 & & & Women & Current & \multicolumn{3}{c}{Screens} & Cancer & \\
\cmidrule(lr){6-8}
Network & Participants & Age, years & (\%) & smokers (\%) & All & Baseline & Follow-up & screens & BAC \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")


HIST = {8070: "Squamous-cell carcinoma", 8041: "Small-cell carcinoma", 8012: "Large-cell carcinoma",
        8046: "Non-small-cell carcinoma, NOS", 8560: "Adenosquamous carcinoma"}
STAGE = {110: "IA", 120: "IB", 210: "IIA", 220: "IIB", 310: "IIIA", 320: "IIIB", 400: "IV"}


def table_examples(E):
    """Examples of discordant test screens chosen by the fixed procedure of scripts/examples.py."""
    rnd = {0: "Baseline", 1: "First follow-up", 2: "Second follow-up"}
    att = {"solid": "solid", "part_solid": "part-solid", "ggo": "ground-glass"}
    groups = {"cancer_ref_only": "Cancer screens positive only under Lung-RADS v2022",
              "cancer_new_only": "Cancer screens positive only under the selected rules",
              "control_ref_only": "Screens without cancer positive only under Lung-RADS v2022",
              "control_new_only": "Screens without cancer positive only under the selected rules"}

    def clause(c):
        a = sorted(c["attenuation"], key=list(att).index)
        kind = "nodule of any attenuation" if len(a) == 3 else " or ".join(att[x] for x in a) + " nodule"
        status = {"all": "", "new": "new ", "growing": "growing ", "new_or_growing": "new or growing "}[c["status"]]
        where = {"baseline": "at baseline", "followup": "at follow-up", "any": ""}[c["round"]]
        if c["round"] == "baseline":
            status = ""
        return f"{status}{kind} {where} $\\geq${c['min_size']:g}~mm".replace("  ", " ").strip()

    def negative(x):
        t = x["other_threshold"]
        return "Negative: not covered at any size" if t is None else f"Negative: below {t:g}~mm"

    def hist(h):
        return "Bronchioloalveolar carcinoma" if 8250 <= h <= 8254 else HIST.get(h, "Adenocarcinoma")

    rows, n = [], 0
    for g, lab in groups.items():
        r = E[g]; top = r["patterns"][0]
        rows.append(f"\\multicolumn{{4}}{{p{{15.6cm}}}}{{\\textit{{{lab} (n = {r['n']:,}); most frequent decisive nodule: {top['pattern']}, "
                    f"{top['n']:,} screens, {top['min']:g}--{top['max']:g}~mm}}}} \\\\")
        for x in r["examples"]:
            n += 1
            others = x["other_nodules"]
            nod = (f"{rnd[x['k']]}; {x['status'] + ' ' if x['status'] != 'baseline' else ''}{x['attenuation']} nodule, "
                   f"{x['diameter']:g}~mm" + ("" if not others else f"; other nodule{'s' if len(others) > 1 else ''} " + ", ".join(f"{o:g}" for o in others) + "~mm"))
            dev = x["direction"].split("->")[0]
            pos = "Positive: " + clause(x["clause"])
            ref, new = (pos, negative(x)) if g.endswith("ref_only") else (negative(x), pos)
            out = ("No lung cancer diagnosed during the trial" if not x["lung_cancer"] else
                   f"{hist(x['histology'])}, stage {STAGE.get(x['stage'], 'unknown')}, diagnosed {x['days_to_diagnosis']:.0f} days after the screen")
            rows.append(f"{n}. {nod} & {ref} & {new} (rule selected on {dev}) & {out} \\\\")
        rows.append("\\midrule")
    rows = rows[:-1]
    write("table_examples.tex", r"""\begin{table}[!t]
\centering\footnotesize
\caption{Examples of test screens classified differently by the selected rules and Lung-RADS v2022. The decisive nodule is the largest nodule that makes the screen positive under the rule that calls it positive; diameters are means of the long and perpendicular diameters. Examples were chosen by a fixed procedure: in each group, the screen with the median diameter of the decisive nodule among screens with the most frequent kind of decisive nodule (for cancer screens, also with the more frequent histology class within it, bronchioloalveolar carcinoma or other); for cancer screens, also the most advanced stage among screens with that kind of nodule. Each test screen is classified by the rule selected on the other network. NOS, not otherwise specified.}
\label{tab:examples}
\setlength{\tabcolsep}{3pt}
\newcolumntype{L}[1]{>{\raggedright\arraybackslash}p{#1}}
\begin{tabular}{L{4.2cm}L{3.4cm}L{3.5cm}L{3.9cm}}
\toprule
Screen and decisive nodule & Lung-RADS v2022 & Selected rules & Outcome \\
\midrule
""" + "\n".join(rows) + r"""
\bottomrule
\end{tabular}
\end{table}
""")


def main():
    P = json.load(open(os.path.join(RES, "primary.json")))
    sec = json.load(open(os.path.join(RES, "secondary.json")))
    M = json.load(open(os.path.join(RES, "methods.json")))
    final = json.load(open(os.path.join(RES, "final_rule.json")))
    if not DRY:
        table_data()
    table_primary(P, sec); table_rules(P, final); table_methods(M)
    if os.path.exists(os.path.join(RES, "examples.json")):
        table_examples(json.load(open(os.path.join(RES, "examples.json"))))
    figure_methods(M); numbers(P, sec, M, final)
    if not DRY:
        figure_tradeoff(P)
    print("tables and figures written", "(dry run)" if DRY else "")


if __name__ == "__main__":
    sys.exit(main())
