"""Additional results of the supplement (Section S5) from results/*.json.

    python paper/make_supplement.py
"""
import json, os, sys

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "src"))
from nlst_rules.rules import render                    # noqa: E402
RES = os.path.join(ROOT, "results")
STAGE = {110: "IA", 120: "IB", 210: "IIA", 220: "IIB", 310: "IIIA", 320: "IIIB", 400: "IV"}
SUBGROUPS = {"female": "Women", "male": "Men", "age_lt65": "Age $<$ 65 years", "age_ge65": "Age $\\geq$ 65 years",
             "current_smoker": "Current smokers", "former_smoker": "Former smokers"}


def histology(h):
    h = int(h or 0)
    if 8250 <= h <= 8254:
        return "Bronchioloalveolar carcinoma"
    if h == 8560:
        return "Adenosquamous carcinoma"
    if 8140 <= h <= 8575:
        return "Adenocarcinoma (other)"
    return {8070: "Squamous-cell carcinoma", 8041: "Small-cell carcinoma", 8012: "Large-cell carcinoma",
            8046: "Non-small-cell carcinoma, NOS"}.get(h, f"Other ({h})")


def table(caption, spec, header, rows):
    return ("\\begin{table}[h]\n\\centering\\small\n\\caption{" + caption + "}\n\\begin{tabular}{" + spec + "}\n\\toprule\n"
            + header + " \\\\\n\\midrule\n" + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}\n\\end{table}\n")


def main():
    S = json.load(open(os.path.join(RES, "secondary.json")))
    d = S["discordant_cancers"]
    ref = [x for x in d if x["pos_ref"] and not x["pos_new"]]
    new = [x for x in d if x["pos_new"] and not x["pos_ref"]]
    rows = [f"{c} & {sum(histology(x['histology']) == c for x in ref)} & {sum(histology(x['histology']) == c for x in new)} \\\\"
            for c in sorted({histology(x["histology"]) for x in d})]
    rows.append("\\midrule")
    rows += [f"Stage {lab} & {sum(x['stage'] == code for x in ref)} & {sum(x['stage'] == code for x in new)} \\\\"
             for code, lab in STAGE.items() if any(x["stage"] == code for x in d)]
    rows.append("\\midrule")
    rows.append(f"Baseline screen & {sum(x['k'] == 0 for x in ref)} & {sum(x['k'] == 0 for x in new)} \\\\")
    rows.append(f"Follow-up screen & {sum(x['k'] > 0 for x in ref)} & {sum(x['k'] > 0 for x in new)} \\\\")
    out = [table("Discordant cancer screens on the pooled test screens: cancer screens positive under one rule only.", "lrr",
                 f" & Lung-RADS v2022 only (n = {len(ref)}) & Selected rules only (n = {len(new)})", rows)]

    SG = json.load(open(os.path.join(RES, "subgroup_ci.json")))          # written by paper/make_figures.py (Figure 4)
    SG_KEY = {"female": "Women", "male": "Men", "age_lt65": "Age < 65 years", "age_ge65": "Age $\\geq$ 65 years",
              "current_smoker": "Current smokers", "former_smoker": "Former smokers"}
    sg_ci = lambda t: f"{100 * t[0]:+.2f} ({100 * t[1]:+.2f} to {100 * t[2]:+.2f})".replace("-", "$-$")
    rows = [f"{SUBGROUPS[g]} & {v['new']['cancer_screens']} & {100 * v['new']['sensitivity']:.1f} & {100 * v['ref']['sensitivity']:.1f} & "
            f"{sg_ci(SG[SG_KEY[g]]['sens_diff'])} & {100 * v['new']['fpr']:.2f} & {100 * v['ref']['fpr']:.2f} & "
            f"{sg_ci(SG[SG_KEY[g]]['fpr_diff'])} \\\\" for g, v in S["subgroups"].items()]
    out.append("\\begin{table}[h]\n\\centering\\small\n\\caption{Subgroups, pooled test screens. Sensitivity and false-positive rate (FPR) in \\%, "
               "differences in percentage points with 95\\% CI (Tango score interval for sensitivity, participant bootstrap with 2,000 resamples for FPR).}\n"
               "\\resizebox{\\textwidth}{!}{\\begin{tabular}{lrrrlrrl}\n\\toprule\n"
               "Subgroup & Cancer screens & Sens., rule & Sens., v2022 & Difference & FPR, rule & FPR, v2022 & Difference \\\\\n\\midrule\n"
               + "\n".join(rows) + "\n\\bottomrule\n\\end{tabular}}\n\\end{table}\n")

    arrow = lambda k: k.replace("->", " $\\rightarrow$ ")
    rows = [f"{arrow(k)} & {100 * v['new']['sensitivity']:.1f} & {100 * v['ref']['sensitivity']:.1f} & {100 * v['new']['fpr']:.2f} & "
            f"{100 * v['ref']['fpr']:.2f} \\\\" for k, v in S["perturbation"].items()]
    rows += [f"{arrow(k)}, perifissural rule simulated & -- & -- & {100 * v['new']:.2f} & {100 * v['ref']:.2f} \\\\"
             for k, v in S["perifissural"].items()]
    out.append(table("Robustness on each test network (derivation $\\rightarrow$ test): all mean diameters changed by $\\pm$1~mm, and "
                     "the perifissural rule of Lung-RADS v2022 simulated in both rules (19.8\\% of solid baseline nodules of 6 to "
                     "under 10~mm in screens without cancer downgraded, mean of 200 draws). Sensitivity and FPR in \\%.", "lrrrr",
                     "Condition & Sensitivity, rule & Sensitivity, v2022 & FPR, rule & FPR, v2022", rows))

    R = json.load(open(os.path.join(RES, "protocol.json")))
    ci = lambda t: f"{100 * t[0]:+.2f} ({100 * t[1]:+.2f} to {100 * t[2]:+.2f})".replace("-", "$-$")
    sa = R["sensitivity_analyses"]
    rows = []
    for key, lab in (("missing_comparison_as_new", "Nodules without comparison record treated as new"),
                     ("missing_comparison_excluded", "Nodules without comparison record excluded"),
                     ("short_followup_controls_excluded", f"Screens without cancer with $<$1 year cancer-free follow-up excluded ({sa['short_followup_controls_excluded']['excluded']})"),
                     ("two_year_window", "Outcome window of 2 years after the last screen")):
        v = sa[key]
        rows.append(f"{lab} & {v['cancer_screens']} & {100 * v['sens_new']:.1f} & {100 * v['sens_ref']:.1f} & {ci(v['sens_diff'])} & "
                    f"{100 * v['fpr_new']:.2f} & {100 * v['fpr_ref']:.2f} & {ci(v['fpr_diff'])} & {('yes' if v['success'] else 'no') + ('$^c$' if key == 'missing_comparison_excluded' else '')} \\\\")
    g = sa["gee"]
    rows.append(f"GEE (identity link, exchangeable, robust standard errors) & 642 & & & {ci(g['sensitivity'])} & & & {ci(g['fpr'])} & {'yes' if g['sensitivity'][1] > -0.03 and g['fpr'][2] < 0 else 'no'} \\\\")
    cs = R["clinically_significant"]
    rows.append(f"Clinically significant cancer (excluding BAC)$^a$ & {cs['cancer_screens']} & {100 * cs['sens_new']:.1f} & {100 * cs['sens_ref']:.1f} & {ci(cs['sens_diff'])} & & & & {'yes' if cs['sens_diff'][1] > -0.03 else 'no'} \\\\")
    a4 = R["at_4A_or_higher"]
    rows.append(f"Positive at category 4A or higher$^b$ & {a4['cancer_screens']} & {100 * a4['sens_new']:.1f} & {100 * a4['sens_ref']:.1f} & {ci(a4['sens_diff'])} & "
                f"{100 * a4['fpr_new']:.2f} & {100 * a4['fpr_ref']:.2f} & {ci(a4['fpr_diff'])} & -- \\\\")
    out.append(table("Prespecified sensitivity analyses of the co-primary endpoints, pooled test screens (selected rules versus Lung-RADS v2022). "
                     "Sensitivity and false-positive rate (FPR) in \\%, differences in percentage points (95\\% CI). Criteria met: both prespecified "
                     "criteria (FPR upper bound below 0; sensitivity lower bound above $-3$). $^a$The tables contain no in situ behavior codes; "
                     "bronchioloalveolar carcinoma (BAC) is ICD-O-3 8250--8254. $^b$Category as defined in Section S5; not a success criterion. $^c$Identical to the primary analysis by construction: without a comparison record a nodule counts as pre-existing and not growing, and no clause of either rule applies to such nodules at follow-up.",
                     "p{4.6cm}rrrlrrlc", "Analysis & Cancer screens & Sens., rule & Sens., v2022 & Difference & FPR, rule & FPR, v2022 & Difference & Criteria met",
                     rows).replace("\\begin{tabular}", "\\resizebox{\\textwidth}{!}{\\begin{tabular}").replace("\\end{tabular}", "\\end{tabular}}"))

    rows = []
    for k, lab in (("3", "3"), ("4A", "4A"), ("4B", "4B"), ("4X", "4X (fixed layer)")):
        n_, r_ = R["ppv_by_category"]["new"][k], R["ppv_by_category"]["ref"][k]
        f = lambda v: "--" if v["ppv"] is None else f"{v['screens']:,} & {v['cancers']} & {100 * v['ppv']:.1f}"
        rows.append(f"{lab} & {f(n_)} & {f(r_)} \\\\")
    out.append(table("Positive predictive value (PPV) by the highest category of a screen, pooled test screens. Positive nodules take the higher "
                     "of category 3 and their approximate Lung-RADS v2022 category (Section S5). The ACR expects malignancy in 1--2\\% (3), "
                     "5--15\\% (4A) and $>$15\\% (4B).", "lrrrrrr",
                     " & \\multicolumn{3}{c}{Selected rules} & \\multicolumn{3}{c}{Lung-RADS v2022} \\\\\nCategory & Screens & Cancers & PPV (\\%) & Screens & Cancers & PPV (\\%)", rows))

    C = R["comparators_pooled_test"]
    lab = {"selected_baseline": "Selected rules", "v2022_baseline": "Lung-RADS v2022", "ielcap_baseline": "I-ELCAP (solid and part-solid $\\geq$6 mm, ground-glass $\\geq$8 mm)",
           "brock_6pct_baseline": "Brock model, risk $\\geq$6\\%", "brock_30pct_baseline": "Brock model, risk $\\geq$30\\%",
           "lungrads_v10": "Lung-RADS v1.0 (all rounds)", "nlst": "NLST criterion as recorded (all rounds)"}
    rows = [f"{lab[k]} & {100 * C[k]['sensitivity']:.1f} & {100 * C[k]['fpr']:.2f} \\\\" for k in
            ("selected_baseline", "v2022_baseline", "ielcap_baseline", "brock_6pct_baseline", "brock_30pct_baseline")]
    rows.append("\\midrule")
    rows += [f"{lab[k]} & {100 * C[k]['sensitivity']:.1f} & {100 * C[k]['fpr']:.2f} \\\\" for k in ("lungrads_v10", "nlst")]
    out.append(table("Other comparators on the pooled test screens: baseline screens (upper part) and all rounds (lower part). Brock (PanCan) full "
                     "model with spiculation, family history set to absent, emphysema from the CT abnormality table, longest diameter; the "
                     "thresholds are those of the PanCan management categories (6\\% and 30\\%). All comparators include the fixed 4X layer.",
                     "lrr", "Rule & Sensitivity (\\%) & False-positive rate (\\%)", rows))

    cf, lm, lt, vb, kp = R["cumulative_false_positive"], R["lobe_matched_sensitivity"], R["lead_time"], R["verification"], R["kappa"]
    rows = [f"Participants with $\\geq$1 false-positive screen over three rounds (n = {cf['participants']:,} with three completed screens and no cancer screen) & {100 * cf['new']:.1f}\\% & {100 * cf['ref']:.1f}\\% \\\\",
            f"Lobe-matched sensitivity (positive nodule in the lobe of the cancer, or 4X; n = {lm['cancer_screens']}, lobe unknown {lm['lobe_unknown']}) & {100 * lm['new']:.1f}\\% & {100 * lm['ref']:.1f}\\% \\\\",
            f"Lead time: cancers at T1 or T2 with a nodule in the same lobe at the previous screen (n = {lt['eligible']}), previous screen positive & {lt['new']} & {lt['ref']} \\\\",
            f"\\quad previous screen positive for a nodule in that lobe & {lt['new_lobe']} & {lt['ref_lobe']} \\\\",
            f"Screens without cancer positive under the rule but negative in NLST (not worked up) & {vb['control_pos_new_nlst_negative']} & {vb['control_pos_ref_nlst_negative']} \\\\",
            f"Cancer screens negative in NLST ({vb['cancer_screens_nlst_negative']}) that the rule calls positive & {vb['cancer_nlst_negative_pos_new']} & {vb['cancer_nlst_negative_pos_ref']} \\\\"]
    out.append(table("Further prespecified secondary analyses, pooled test screens. Agreement per screen (all screens) between the rules selected on LSS, "
                     f"on ACRIN and on all participants: Cohen's $\\kappa$ {kp['LSS-ACRIN']:.2f} (LSS--ACRIN), {kp['LSS-ALL']:.2f} (LSS--all) and "
                     f"{kp['ACRIN-ALL']:.2f} (ACRIN--all).", "p{9.6cm}rr", "Analysis & Selected rules & Lung-RADS v2022", rows))

    hist = {**{h: "BAC" for h in range(8250, 8255)}, 8070: "SqCC", 8071: "SqCC", 8072: "SqCC", 8041: "SCLC", 8012: "LCC", 8046: "NSCLC, NOS", 8560: "Adenosquamous"}
    hname = lambda h: hist.get(int(h or 0), "Adenocarcinoma" if 8140 <= int(h or 0) <= 8575 else f"Other ({int(h or 0)})")
    rows = []
    for x in sorted(d, key=lambda x: (x["pos_new"], x["direction"], x["k"], x["stage"] or 0)):
        rows.append(f"{'Selected rules' if x['pos_new'] else 'Lung-RADS v2022'} & {x['direction'].replace('->', ' $\\rightarrow$ ')} & T{x['k']} & "
                    f"{STAGE.get(int(x['stage'] or 0), '--')} & {hname(x['histology'])} \\\\")
    longt = ("\\clearpage\n\\begin{longtable}{lllll}\n\\caption{Discordant cancer screens, case by case (pooled test screens). BAC, bronchioloalveolar carcinoma; "
             "LCC, large-cell; NOS, not otherwise specified; SCLC, small-cell; SqCC, squamous-cell carcinoma.}\\\\\n\\toprule\n"
             "Positive only under & Direction & Round & Stage & Histology \\\\\n\\midrule\n\\endhead\n" + "\n".join(rows) + "\n\\bottomrule\n\\end{longtable}\n")
    out.append(longt)
    out = [out[i] for i in (3, 4, 5, 6, 1, 2, 0, 7)]             # order of first citation in the main text
    ex_path = os.path.join(RES, "examples.json")
    if os.path.exists(ex_path):
        E = json.load(open(ex_path))
        lab = {"cancer_ref_only": "Cancer screens positive only under Lung-RADS v2022",
               "cancer_new_only": "Cancer screens positive only under the selected rules",
               "control_ref_only": "Screens without cancer positive only under Lung-RADS v2022",
               "control_new_only": "Screens without cancer positive only under the selected rules"}
        rows = []
        for g, t in lab.items():
            rows.append(f"\\multicolumn{{3}}{{l}}{{\\textit{{{t} (n = {E[g]['n']:,})}}}} \\\\")
            rows += [f"\\quad {q['pattern'].capitalize()} & {q['n']:,} & {q['median']:g} ({q['min']:g}--{q['max']:g}) \\\\"
                     for q in E[g]["patterns"]]
        out.append(table("Decisive nodules of the discordant pooled test screens: the largest nodule that makes the screen positive "
                         "under the rule that calls it positive, by status and attenuation (scripts/examples.py; descriptive, "
                         "added after the primary evaluation).", "lrr",
                         "Group and decisive nodule & Screens & Mean diameter, median (range), mm", rows))
    O = R["objective4_single_arm_selection"]
    ROUND = {"baseline": "Baseline", "followup": "Follow-up", "any": "Any"}
    rows = []
    for arm, name in (("retuned", "Re-tuned Lung-RADS"), ("greedy", "Greedy rule learner")):
        v = O[arm]["pooled"]
        rows.append(f"\\multicolumn{{5}}{{p{{14.5cm}}}}{{\\textit{{{name}: sensitivity {100 * v['sens_new']:.1f}\\%, difference {ci(v['sens_diff'])}; "
                    f"FPR {100 * v['fpr_new']:.2f}\\%, difference {ci(v['fpr_diff'])}; criteria {'met' if v['success'] else 'not met'}}}}} \\\\")
        for net in ("LSS", "ACRIN"):
            rows.append(f"\\quad Selected on {net} & & & & \\\\")
            for l in render(O[arm][f"rule_{net}"]).splitlines()[2:]:
                c = ["--" if x.strip() == "-" else x.strip().replace(">=", "$\\geq$") for x in l.strip("|").split("|")]
                c[0] = "\\qquad " + ROUND.get(c[0], c[0])
                rows.append(" & ".join(c) + " \\\\")
        rows.append("\\midrule")
    out.append(table("Rules chosen by the prespecified selection criterion from the candidates of the re-tuned Lung-RADS arm alone and of "
                     "the greedy rule learner alone, with their pooled test sensitivity and false-positive rate (FPR) and the differences "
                     "from Lung-RADS v2022 in percentage points (95\\% CI); criteria: both prespecified criteria. Each test network is "
                     "classified by the rule selected on the other network. At baseline, every nodule counts as new.",
                     "lllll", "Round & Nodule & Attenuation & Size & Additional condition", rows[:-1]))
    os.makedirs(os.path.join(os.path.dirname(__file__), "supplementary"), exist_ok=True)
    with open(os.path.join(os.path.dirname(__file__), "supplementary", "additional_results.tex"), "w") as f:
        f.write("\n".join(out))
    print("supplement tables written")


if __name__ == "__main__":
    main()
