"""Rule grammar, validity checks, vectorized evaluation and rendering.

A rule is a list of clauses. A nodule is positive (Lung-RADS category 3 or higher) when at least one clause matches it
and its mean diameter is at least the clause threshold; a screen is positive when any of its nodules is positive or when
it falls in the fixed 4X layer. Clauses only add positives, so a rule is monotone: a larger nodule, a spiculated nodule
or an added feature never lowers the category.

Clause fields (all optional except attenuation and min_size):
    round        "baseline" | "followup" | "any"              (default "any")
    status       "all" | "new" | "growing" | "new_or_growing" (default "all"; at baseline every nodule counts as new)
    attenuation  subset of ["solid", "part_solid", "ggo"]
    min_size     mean diameter in mm, 4.0 to 30.0 in steps of 0.5
    spiculated   true -> only spiculated nodules
    upper_lobe   true -> only nodules in an upper lobe
    emphysema    true -> only screens reporting emphysema
    min_nodules  integer >= 2 -> only screens with at least this many nodules
"""
import json

import numpy as np

from .data import SOLID, PART, GGO

ATT = {"solid": SOLID, "part_solid": PART, "ggo": GGO}
ROUNDS = ("baseline", "followup", "any")
STATUSES = ("all", "new", "growing", "new_or_growing")
FLAGS = ("spiculated", "upper_lobe", "emphysema")
GRID_MIN, GRID_MAX, GRID_STEP = 4.0, 30.0, 0.5
MAX_CLAUSES = 8
MAX_LENGTH = 8              # clauses plus restricting conditions; Lung-RADS v2022 needs 3


class InvalidRule(ValueError):
    pass


def validate(rule):
    """Return the rule with defaults filled in; raise InvalidRule if it breaks the grammar."""
    if not isinstance(rule, dict) or not isinstance(rule.get("clauses"), list):
        raise InvalidRule("a rule is an object with a list 'clauses'")
    clauses = rule["clauses"]
    if not 1 <= len(clauses) <= MAX_CLAUSES:
        raise InvalidRule(f"a rule has 1 to {MAX_CLAUSES} clauses")
    out = []
    allowed = {"round", "status", "attenuation", "min_size", "min_nodules", *FLAGS}
    for i, c in enumerate(clauses):
        if not isinstance(c, dict):
            raise InvalidRule(f"clause {i} is not an object")
        unknown = set(c) - allowed
        if unknown:
            raise InvalidRule(f"clause {i}: unknown fields {sorted(unknown)}")
        r, st = c.get("round", "any"), c.get("status", "all")
        att = c.get("attenuation")
        if r not in ROUNDS or st not in STATUSES:
            raise InvalidRule(f"clause {i}: round must be one of {ROUNDS}, status one of {STATUSES}")
        if not isinstance(att, list) or not att or any(a not in ATT for a in att):
            raise InvalidRule(f"clause {i}: attenuation must be a non-empty subset of {list(ATT)}")
        size = c.get("min_size")
        if not isinstance(size, (int, float)) or not GRID_MIN <= size <= GRID_MAX or (size - GRID_MIN) % GRID_STEP:
            raise InvalidRule(f"clause {i}: min_size must be {GRID_MIN}-{GRID_MAX} mm in steps of {GRID_STEP}")
        mn = c.get("min_nodules")
        if mn is not None and (not isinstance(mn, int) or mn < 2):
            raise InvalidRule(f"clause {i}: min_nodules must be an integer of at least 2")
        for f in FLAGS:
            if c.get(f) not in (None, True):
                raise InvalidRule(f"clause {i}: {f} may only be true or absent")
        out.append({"round": r, "status": st, "attenuation": sorted(set(att), key=list(ATT).index),
                    "min_size": float(size), **({"min_nodules": mn} if mn else {}),
                    **{f: True for f in FLAGS if c.get(f)}})
    rule = {"name": rule.get("name", ""), "clauses": out}
    if complexity(rule) > MAX_LENGTH:
        raise InvalidRule(f"rule length {complexity(rule)} exceeds {MAX_LENGTH}")
    return rule


def complexity(rule):
    """Number of clauses plus one per restricting flag or nodule count; the number reported as rule length."""
    return sum(1 + sum(f in c for f in FLAGS) + ("min_nodules" in c) for c in rule["clauses"])


class Evaluator:
    """Evaluates rules on one Dataset; all masks are precomputed once."""

    def __init__(self, ds):
        n, s = ds.nodules, ds.screens
        self.n_screens = len(s)
        self.row = n["row"].to_numpy()
        self.size = n["mean"].to_numpy()
        base = n["k"].to_numpy() == 0
        new = n["new"].to_numpy() | base
        grow = n["growing"].to_numpy() & ~base
        self.round = {"baseline": base, "followup": ~base, "any": np.ones(len(n), bool)}
        self.status = {"all": np.ones(len(n), bool), "new": new, "growing": grow, "new_or_growing": new | grow}
        att = n["att"].to_numpy()
        self.att = {a: att == v for a, v in ATT.items()}
        self.flag = {"spiculated": n["spiculated"].to_numpy(), "upper_lobe": n["upper_lobe"].to_numpy(),
                     "emphysema": s["emphysema"].to_numpy()[self.row]}
        self.count = s["n_nodules"].to_numpy()[self.row]
        self.x4 = s["x4"].to_numpy()
        self.case = s["case"].to_numpy()

    def nodule_positive(self, rule):
        pos = np.zeros(len(self.size), bool)
        for c in rule["clauses"]:
            m = self.round[c["round"]] & self.status[c["status"]] & (self.size >= c["min_size"])
            m &= np.logical_or.reduce([self.att[a] for a in c["attenuation"]])
            for f in FLAGS:
                if c.get(f):
                    m &= self.flag[f]
            if "min_nodules" in c:
                m &= self.count >= c["min_nodules"]
            pos |= m
        return pos

    def screen_positive(self, rule):
        return (np.bincount(self.row[self.nodule_positive(rule)], minlength=self.n_screens) > 0) | self.x4

    def metrics(self, rule=None, positive=None):
        pos = self.screen_positive(rule) if positive is None else positive
        c = self.case
        return {"sensitivity": pos[c].mean(), "fpr": pos[~c].mean(), "positives": int(pos.sum()),
                "tp": int((pos & c).sum()), "fp": int((pos & ~c).sum()), "cases": int(c.sum()), "screens": len(c)}


def render(rule):
    """Lung-RADS-style table (markdown) of the conditions that make a screen positive."""
    lab = {"solid": "solid", "part_solid": "part-solid", "ggo": "ground-glass"}
    st = {"all": "any", "new": "new", "growing": "growing", "new_or_growing": "new or growing"}
    lines = ["| Round | Nodule | Attenuation | Size (mean diameter) | Additional condition |", "|---|---|---|---|---|"]
    for c in rule["clauses"]:
        extra = [x for x, f in (("spiculated", "spiculated"), ("upper lobe", "upper_lobe"), ("emphysema", "emphysema")) if c.get(f)]
        if "min_nodules" in c:
            extra.append(f">= {c['min_nodules']} nodules")
        lines.append(f"| {c['round']} | {st[c['status']] if c['round'] != 'baseline' else 'any'} | "
                     f"{', '.join(lab[a] for a in c['attenuation'])} | >= {c['min_size']:g} mm | {'; '.join(extra) or '-'} |")
    return "\n".join(lines)


def load_rule(path):
    with open(path) as f:
        return validate(json.load(f))
