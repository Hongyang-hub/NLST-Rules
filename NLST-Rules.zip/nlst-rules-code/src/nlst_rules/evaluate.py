"""Rule selection and out-of-network evaluation.

Selection, fixed in advance: among the non-dominated rules of all search arms on the development network, take the
rule with the lowest development false-positive rate whose development sensitivity is at least that of Lung-RADS
v2022 plus 1.0 percentage point; among rules within 0.5 point of that false-positive rate, take the shortest (then the
lowest false-positive rate).

Co-primary endpoints on the test screens, selected rule minus Lung-RADS v2022: the sensitivity difference with a paired
Tango score interval (cancer screens are independent, one per cancer), and the false-positive-rate difference with a
percentile bootstrap that resamples participants within network.
"""
import glob
import json
import os

import numpy as np

from .search import key, nondominated

BUFFER, PARSIMONY = 0.01, 0.005


def load_pool(run_dir):
    """All evaluated rules of all arms under runs/<dev>/, with the arm attached."""
    pool = []
    for f in sorted(glob.glob(os.path.join(run_dir, "*", "s*.json"))):
        with open(f) as fh:
            d = json.load(fh)
        arm = os.path.basename(os.path.dirname(f))
        for r in d["archive"]:
            pool.append({**r, "arm": arm, "seed": d["meta"]["seed"]})
    return pool


def select(pool, reference):
    """Selection rule; `reference` = development metrics of Lung-RADS v2022."""
    seen, uniq = set(), []
    for r in pool:
        k = key(r["rule"])
        if k not in seen:
            seen.add(k)
            uniq.append(r)
    front = nondominated(uniq)
    ok = [r for r in front if r["sensitivity"] >= reference["sensitivity"] + BUFFER - 1e-12]
    if not ok:
        return None
    best_fpr = min(r["fpr"] for r in ok)
    near = [r for r in ok if r["fpr"] <= best_fpr + PARSIMONY]
    return min(near, key=lambda r: (r["length"], r["fpr"]))


def tango_ci(b, c, n, alpha=0.05):
    """Tango (1998) score interval for the difference of paired proportions, delta = (b - c) / n.

    b: pairs positive under the new rule only; c: positive under the reference only; n: number of pairs."""
    from math import sqrt
    z = 1.959963984540054 if alpha == 0.05 else None

    def score(d):
        A = 2 * n
        B = -b - c + (2 * n - b + c) * d
        C = -c * d * (1 - d)
        q = (-B + sqrt(max(B * B - 4 * A * C, 0.0))) / (2 * A)
        var = n * (2 * q + d * (1 - d))
        num = b - c - n * d
        if var <= 0:                                  # degenerate point (e.g., b = c = 0 at d = 0)
            return 0.0 if num == 0 else float(np.sign(num)) * np.inf
        return num / sqrt(var)

    est = (b - c) / n

    def root(lo, hi, target):
        for _ in range(200):
            mid = (lo + hi) / 2
            if (score(mid) - target) * (score(lo) - target) <= 0:
                hi = mid
            else:
                lo = mid
        return (lo + hi) / 2

    lower = -1.0 if score(-1 + 1e-12) <= z else root(-1 + 1e-12, est, z)
    upper = 1.0 if score(1 - 1e-12) >= -z else root(est, 1 - 1e-12, -z)
    return est, lower, upper


def bootstrap_fpr_difference(pos_new, pos_ref, case, pid, network, n_boot=10_000, seed=0):
    """Difference in false-positive rate with a percentile bootstrap over participants, stratified by network."""
    ctrl = ~case
    diff_by = {}
    rng = np.random.default_rng(seed)
    # per participant: number of control screens and of false positives under each rule
    import pandas as pd
    d = pd.DataFrame({"pid": pid[ctrl], "net": network[ctrl], "n": 1,
                      "a": pos_new[ctrl].astype(int), "b": pos_ref[ctrl].astype(int)}).groupby(["net", "pid"]).sum()
    est = (d.a.sum() - d.b.sum()) / d.n.sum()
    stats = np.zeros(n_boot)
    groups = [g for _, g in d.groupby(level="net")]
    for i in range(n_boot):
        tot_n = tot_a = tot_b = 0
        for g in groups:
            idx = rng.integers(len(g), size=len(g))
            tot_n += g.n.to_numpy()[idx].sum()
            tot_a += g.a.to_numpy()[idx].sum()
            tot_b += g.b.to_numpy()[idx].sum()
        stats[i] = (tot_a - tot_b) / tot_n
    return est, np.percentile(stats, 2.5), np.percentile(stats, 97.5)


def compare(pos_new, pos_ref, screens, n_boot=10_000, seed=0):
    """Co-primary endpoints and success criteria for one set of test screens (one direction or both pooled)."""
    case = screens["case"].to_numpy()
    b = int((pos_new & ~pos_ref & case).sum())
    c = int((~pos_new & pos_ref & case).sum())
    n = int(case.sum())
    sens = tango_ci(b, c, n)
    fpr = bootstrap_fpr_difference(pos_new, pos_ref, case, screens["pid"].to_numpy(), screens["network"].to_numpy(),
                                   n_boot=n_boot, seed=seed)
    return {
        "cancer_screens": n, "control_screens": int((~case).sum()), "discordant_new_only": b, "discordant_ref_only": c,
        "sens_new": float(pos_new[case].mean()), "sens_ref": float(pos_ref[case].mean()),
        "fpr_new": float(pos_new[~case].mean()), "fpr_ref": float(pos_ref[~case].mean()),
        "sens_diff": sens, "fpr_diff": fpr,
        "criterion_fpr": bool(fpr[2] < 0), "criterion_sens": bool(sens[1] > -0.03),
        "success": bool(fpr[2] < 0 and sens[1] > -0.03),
    }
