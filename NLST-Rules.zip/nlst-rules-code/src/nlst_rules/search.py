"""Search frameworks with a common evaluation budget.

The budget counts distinct rules evaluated; a rule proposed again costs nothing. Every evaluated rule is kept with its
objectives (sensitivity, false-positive rate, rule length), so that the non-dominated rules of a run can enter the
candidate pool of the selection step. Variation is supplied by an offspring generator (genetic programming).
"""
import json
import time

import numpy as np
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

from .rules import complexity

STALL_GENERATIONS = 20       # a population search stops after this many generations without a new rule


def key(rule):
    return json.dumps(sorted(json.dumps(c, sort_keys=True) for c in rule["clauses"]))


class Budget:
    """Evaluates rules on the development data, caches results and records every distinct rule."""

    def __init__(self, evaluator, n_evals):
        self.ev, self.n_evals = evaluator, n_evals
        self.cache, self.archive = {}, []
        self.t0 = time.time()
        self.stalled = False                # set when a search stops without new rules (see STALL_GENERATIONS)

    @property
    def left(self):
        return self.n_evals - len(self.archive)

    def evaluate(self, rule):
        k = key(rule)
        if k not in self.cache:
            if self.left <= 0:
                return None
            m = self.ev.metrics(rule)
            rec = {"rule": rule, "sensitivity": m["sensitivity"], "fpr": m["fpr"], "length": complexity(rule),
                   "eval": len(self.archive), "seconds": time.time() - self.t0}
            self.cache[k] = rec
            self.archive.append(rec)
        return self.cache[k]

    def objectives(self, recs):
        return np.array([[-r["sensitivity"], r["fpr"], r["length"]] for r in recs])


def nondominated(recs):
    F = np.array([[-r["sensitivity"], r["fpr"], r["length"]] for r in recs])
    return [recs[i] for i in NonDominatedSorting().do(F, only_non_dominated_front=True)]


def _crowding(F):
    n, m = F.shape
    d = np.zeros(n)
    if n <= 2:
        return np.full(n, np.inf)
    for j in range(m):
        o = np.argsort(F[:, j])
        span = F[o[-1], j] - F[o[0], j] or 1.0
        d[o[0]] = d[o[-1]] = np.inf
        d[o[1:-1]] += (F[o[2:], j] - F[o[:-2], j]) / span
    return d


def _rank_and_crowding(F):
    fronts = NonDominatedSorting().do(F)
    rank, crowd = np.empty(len(F), int), np.empty(len(F))
    for i, fr in enumerate(fronts):
        rank[fr] = i
        crowd[fr] = _crowding(F[fr])
    return rank, crowd


def nsga2(budget, initial, variation, rng, pop_size=100, max_generations=1000):
    pop = [r for r in (budget.evaluate(x) for x in initial) if r][:pop_size]
    stall = 0
    for _ in range(max_generations):
        if budget.left <= 0:
            break
        F = budget.objectives(pop)
        rank, crowd = _rank_and_crowding(F)
        idx = []
        for _ in range(pop_size):                       # binary tournament: rank, then crowding distance
            a, b = rng.integers(len(pop), size=2)
            idx.append(a if (rank[a], -crowd[a]) <= (rank[b], -crowd[b]) else b)
        parents = [pop[i]["rule"] for i in idx]
        children = variation.offspring(parents, pop_size)
        before = len(budget.archive)
        new = [r for r in (budget.evaluate(c) for c in children) if r]
        stall = 0 if len(budget.archive) > before else stall + 1
        if stall >= STALL_GENERATIONS:
            budget.stalled = True
            break
        union = {key(r["rule"]): r for r in pop + new}.values()
        union = list(union)
        F = budget.objectives(union)
        rank, crowd = _rank_and_crowding(F)
        order = np.lexsort((-crowd, rank))
        pop = [union[i] for i in order[:pop_size]]
    return budget.archive


def map_elites(budget, initial, variation, rng, batch=100, sens_bin=0.005, max_iterations=1000):
    """Archive over rule length x sensitivity bin; each cell keeps the rule with the lowest false-positive rate."""
    grid = {}

    def place(r):
        cell = (r["length"], int(r["sensitivity"] // sens_bin))
        if cell not in grid or r["fpr"] < grid[cell]["fpr"]:
            grid[cell] = r

    for r in (budget.evaluate(x) for x in initial):
        if r:
            place(r)
    stall = 0
    for _ in range(max_iterations):
        if budget.left <= 0:
            break
        elites = list(grid.values())
        parents = [elites[i]["rule"] for i in rng.integers(len(elites), size=batch)]
        before = len(budget.archive)
        for r in (budget.evaluate(c) for c in variation.offspring(parents, batch)):
            if r:
                place(r)
        stall = 0 if len(budget.archive) > before else stall + 1
        if stall >= STALL_GENERATIONS:
            budget.stalled = True
            break
    return budget.archive


def random_search(budget, initial, generator, rng, max_draws=1_000_000):
    for x in initial:
        budget.evaluate(x)
    for _ in range(max_draws):
        if budget.left <= 0:
            break
        budget.evaluate(generator(rng))
    return budget.archive
