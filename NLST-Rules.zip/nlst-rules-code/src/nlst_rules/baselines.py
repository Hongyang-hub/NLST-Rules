"""Deterministic comparison arms: re-tuned Lung-RADS and a greedy rule learner in the grammar.

Re-tuned Lung-RADS keeps the structure of Lung-RADS v2022 (baseline solid, baseline part-solid, new ground glass,
new or growing solid or part-solid at follow-up) and searches all four thresholds exhaustively. The greedy rule learner
(sequential covering) starts from the fixed 4X layer and adds, one at a time, the clause with the best gain,
cancer screens gained minus false positives added / L, until no clause has a positive gain or the length cap is
reached; L is the number of false positives accepted per cancer screen gained, and there is one path per value
of L. Both arms are deterministic and not limited by the evaluation budget.
"""
import itertools

import numpy as np

from .gp import GRID
from .rules import ATT, FLAGS, ROUNDS, STATUSES, InvalidRule, validate

FP_PER_CASE = (10, 25, 50, 100, 200)


def _screen_max(ev, mask):
    """Largest mean diameter per screen among nodules selected by mask (-inf when none)."""
    out = np.full(ev.n_screens, -np.inf)
    np.maximum.at(out, ev.row[mask], ev.size[mask])
    return out


def retuned_lungrads(ev, solid=GRID[GRID <= 15], part=GRID[GRID <= 15], ggo=GRID, followup=GRID[GRID <= 10]):
    base, fu = ev.round["baseline"], ev.round["followup"]
    m_solid = _screen_max(ev, base & ev.att["solid"])
    m_part = _screen_max(ev, base & ev.att["part_solid"])
    m_ggo = _screen_max(ev, ev.status["new"] & ev.att["ggo"])
    m_fu = _screen_max(ev, fu & ev.status["new_or_growing"] & (ev.att["solid"] | ev.att["part_solid"]))
    case, x4 = ev.case, ev.x4
    n_case, n_ctrl = case.sum(), (~case).sum()
    out = []
    for t3, t4 in itertools.product(ggo, followup):
        rest = x4 | (m_ggo >= t3) | (m_fu >= t4)
        for t1 in solid:
            a = rest | (m_solid >= t1)
            for t2 in part:
                pos = a | (m_part >= t2)
                out.append((t1, t2, t3, t4, (pos & case).sum() / n_case, (pos & ~case).sum() / n_ctrl))
    return np.array(out)


def retuned_rule(t1, t2, t3, t4):
    return validate({"name": "re-tuned Lung-RADS", "clauses": [
        {"round": "baseline", "attenuation": ["solid"], "min_size": float(t1)},
        {"round": "baseline", "attenuation": ["part_solid"], "min_size": float(t2)},
        {"round": "any", "status": "new", "attenuation": ["ggo"], "min_size": float(t3)},
        {"round": "followup", "status": "new_or_growing", "attenuation": ["solid", "part_solid"], "min_size": float(t4)}]})


def candidate_clauses():
    atts = [list(c) for r in range(1, 4) for c in itertools.combinations(ATT, r)]
    for rnd, st, att, size in itertools.product(ROUNDS, STATUSES, atts, GRID):
        if rnd == "baseline" and st != "all":
            continue                                     # status has no effect at baseline
        base = {"round": rnd, "status": st, "attenuation": att, "min_size": float(size)}
        yield base
        for f in FLAGS:
            yield {**base, f: True}


def greedy_rules(ev, fp_per_case=FP_PER_CASE):
    clauses = list(candidate_clauses())
    pos = np.empty((len(clauses), ev.n_screens), bool)
    for i, c in enumerate(clauses):
        pos[i] = np.bincount(ev.row[ev.nodule_positive({"clauses": [c]})], minlength=ev.n_screens) > 0
    hit_case, hit_ctrl = pos[:, ev.case], pos[:, ~ev.case]
    rules = []
    for L in fp_per_case:
        cur, chosen = ev.x4.copy(), []
        while True:
            score = (hit_case & ~cur[ev.case]).sum(1) - (hit_ctrl & ~cur[~ev.case]).sum(1) / L
            best = int(np.argmax(score))
            if score[best] <= 0:
                break
            try:
                rule = validate({"name": f"greedy L={L}", "clauses": [clauses[j] for j in chosen + [best]]})
            except InvalidRule:                                   # length cap reached
                break
            chosen.append(best)
            cur |= pos[best]
            rules.append({"fp_per_case": L, "rule": rule})
    return rules
