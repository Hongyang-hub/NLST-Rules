"""Readable lung cancer screening management rules on the open NLST CT-arm tables."""
