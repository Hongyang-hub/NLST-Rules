"""Grammar-based variation operators for rules: random rules, mutation and crossover.

Every operator returns a rule that passes `rules.validate`; operators that would break the grammar are retried, and after
a few failures the parent is returned unchanged.
"""
import copy

import numpy as np

from .rules import ATT, FLAGS, GRID_MAX, GRID_MIN, GRID_STEP, MAX_CLAUSES, ROUNDS, STATUSES, InvalidRule, validate

GRID = np.arange(GRID_MIN, GRID_MAX + GRID_STEP / 2, GRID_STEP)
P_FLAG, P_COUNT = 0.1, 0.05


def random_clause(rng):
    att = [a for a in ATT if rng.random() < 0.5] or [list(ATT)[rng.integers(len(ATT))]]
    c = {"round": ROUNDS[rng.integers(len(ROUNDS))], "status": STATUSES[rng.integers(len(STATUSES))],
         "attenuation": att, "min_size": float(GRID[rng.integers(len(GRID))])}
    for f in FLAGS:
        if rng.random() < P_FLAG:
            c[f] = True
    if rng.random() < P_COUNT:
        c["min_nodules"] = int(rng.integers(2, 6))
    return c


def random_rule(rng, max_clauses=4):
    for _ in range(100):
        try:
            return validate({"clauses": [random_clause(rng) for _ in range(rng.integers(1, max_clauses + 1))]})
        except InvalidRule:
            continue
    raise RuntimeError("could not draw a valid rule")


def _step(size, rng):
    delta = rng.choice([0.5, 1.0, 2.0, 4.0]) * rng.choice([-1, 1])
    return float(np.clip(size + delta, GRID_MIN, GRID_MAX))


def mutate(rule, rng, tries=10):
    for _ in range(tries):
        r = copy.deepcopy(rule)
        cl = r["clauses"]
        c = cl[rng.integers(len(cl))]
        op = rng.integers(9)
        if op == 0:
            c["min_size"] = _step(c["min_size"], rng)
        elif op == 1:
            c["round"] = ROUNDS[rng.integers(len(ROUNDS))]
        elif op == 2:
            c["status"] = STATUSES[rng.integers(len(STATUSES))]
        elif op == 3:
            a = list(ATT)[rng.integers(len(ATT))]
            c["attenuation"] = [x for x in c["attenuation"] if x != a] if a in c["attenuation"] else c["attenuation"] + [a]
        elif op == 4:
            f = FLAGS[rng.integers(len(FLAGS))]
            c.pop(f) if c.get(f) else c.__setitem__(f, True)
        elif op == 5:
            c.pop("min_nodules") if "min_nodules" in c else c.__setitem__("min_nodules", int(rng.integers(2, 6)))
        elif op == 6 and len(cl) < MAX_CLAUSES:
            cl.append(random_clause(rng))
        elif op == 7 and len(cl) > 1:
            cl.pop(rng.integers(len(cl)))
        elif op == 8 and len(cl) < MAX_CLAUSES:
            d = copy.deepcopy(c)
            d["min_size"] = _step(d["min_size"], rng)
            cl.append(d)
        else:
            continue
        try:
            return validate(r)
        except InvalidRule:
            continue
    return rule


def crossover(a, b, rng, tries=10):
    pool = a["clauses"] + b["clauses"]
    for _ in range(tries):
        take = [c for c in pool if rng.random() < 0.5]
        if not take:
            continue
        try:
            return validate({"clauses": copy.deepcopy(take[:MAX_CLAUSES])})
        except InvalidRule:
            continue
    return a


class GPVariation:
    """Standard offspring generator: crossover with probability 0.9, then mutation."""

    name = "gp"

    def __init__(self, rng, p_cross=0.9):
        self.rng, self.p_cross = rng, p_cross

    def offspring(self, parents, n):
        out = []
        for i in range(n):
            a = parents[(2 * i) % len(parents)]
            b = parents[(2 * i + 1) % len(parents)]
            child = crossover(a, b, self.rng) if self.rng.random() < self.p_cross else a
            out.append(mutate(child, self.rng))
        return out
