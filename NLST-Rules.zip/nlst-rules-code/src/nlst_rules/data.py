"""Screens and nodules of the NLST CT arm, built from the open IDC tables.

Unit of analysis: a completed screen (participant x round, screen result codes 1-6). Each first lung cancer is attributed
to the last completed screen before diagnosis; that screen is a cancer screen when the diagnosis falls before the next
completed screen, or within 365 days when there is none. Nodules are code-51 abnormalities (non-calcified nodule or mass
of 4 mm or more), joined to their comparison record of the same screen.
"""
from dataclasses import dataclass
import os

import numpy as np
import pandas as pd

RAW = os.path.join(os.path.dirname(__file__), "..", "..", "data", "raw", "idc_v25")
SOLID, PART, GGO = 0, 1, 2
UPPER_LOBES = {1, 4}            # right upper, left upper (lingula, code 5, is reported separately)


def _num(s):
    return pd.to_numeric(s.astype(str).str.strip().replace("", np.nan), errors="coerce")


@dataclass
class Dataset:
    screens: pd.DataFrame       # one row per screen; column `row` = position used by nodules
    nodules: pd.DataFrame       # one row per code-51 nodule; column `row` = screen it belongs to

    def subset(self, mask):
        """Screens selected by a boolean mask (e.g., one network), with their nodules re-indexed."""
        s = self.screens[np.asarray(mask)].copy()
        old = s["row"].to_numpy()
        remap = pd.Series(np.arange(len(s)), index=old)
        n = self.nodules[self.nodules["row"].isin(old)].copy()
        n["row"] = remap.loc[n["row"]].to_numpy()
        s["row"] = np.arange(len(s))
        return Dataset(s.reset_index(drop=True), n.reset_index(drop=True))


def load(raw=RAW):
    p = pd.read_parquet(os.path.join(raw, "nlst_prsn.parquet"))
    ct_arm = set(pd.read_parquet(os.path.join(raw, "nlst_screen.parquet")).pid)
    p = p[p.pid.isin(ct_arm)].copy()
    p["dx"] = _num(p.candx_days)
    p["lc"] = p.cancyr.astype(str).str.strip() != ""
    p["histology"] = _num(p.de_type)
    p["stage"] = _num(p.de_stag)
    p["cancer_free_days"] = _num(p.canc_free_days)

    rows = []
    for k in range(3):
        s = pd.DataFrame({"pid": p.pid.values, "k": k, "d": _num(p[f"scr_days{k}"]).values, "res": _num(p[f"scr_res{k}"]).values,
                          "lc": p.lc.values, "dx": p.dx.values, "histology": p.histology.values, "stage": p.stage.values,
                          "cancer_free_days": p.cancer_free_days.values})
        rows.append(s[s.d.notna() & s.res.between(1, 6)])
    S = pd.concat(rows).sort_values(["pid", "k"]).reset_index(drop=True)
    S["next_d"] = S.groupby("pid").d.shift(-1)
    end = S.next_d.fillna(S.d + 365)
    S["case"] = S.lc & (S.dx >= S.d) & (S.dx < end)
    S["network"] = np.where(S.pid.astype(str).str[0] == "1", "LSS", "ACRIN")
    S["nlst_positive"] = S.res.isin([4, 5, 6])
    # clinically significant: exclude bronchioloalveolar carcinoma (ICD-O-3 8250-8254) among cancer screens
    S["bac"] = S.case & S.histology.between(8250, 8254)

    a = pd.read_parquet(os.path.join(raw, "nlst_ctab.parquet"))
    c = pd.read_parquet(os.path.join(raw, "nlst_ctabc.parquet"))
    for col in ["study_yr", "sct_ab_desc", "sct_long_dia", "sct_perp_dia", "sct_pre_att", "sct_ab_num", "sct_margins", "sct_epi_loc"]:
        a[col] = _num(a[col])
    for col in ["study_yr", "sct_ab_num", "sct_ab_gwth", "sct_ab_preexist", "sct_ab_attn"]:
        c[col] = _num(c[col])
    key = pd.Series(np.arange(len(S)), index=pd.MultiIndex.from_arrays([S.pid, S.k]))

    emph = a[a.sct_ab_desc == 59][["pid", "study_yr"]].drop_duplicates()
    S["emphysema"] = pd.MultiIndex.from_arrays([S.pid, S.k]).isin(pd.MultiIndex.from_arrays([emph.pid, emph.study_yr.astype(int)]))

    n = a[a.sct_ab_desc == 51].merge(c[["pid", "study_yr", "sct_ab_num", "sct_ab_gwth", "sct_ab_preexist", "sct_ab_attn"]],
                                     on=["pid", "study_yr", "sct_ab_num"], how="left")
    idx = pd.MultiIndex.from_arrays([n.pid, n.study_yr.astype(int)])
    n = n[idx.isin(key.index)].copy()
    n["row"] = key.loc[pd.MultiIndex.from_arrays([n.pid, n.study_yr.astype(int)])].to_numpy()
    N = pd.DataFrame({
        "row": n.row.to_numpy(),
        "k": n.study_yr.astype(int).to_numpy(),
        "att": np.select([n.sct_pre_att == 2, n.sct_pre_att == 3], [GGO, PART], SOLID),
        "mean": ((n.sct_long_dia + n.sct_perp_dia.fillna(n.sct_long_dia)) / 2).to_numpy(),
        "long": n.sct_long_dia.to_numpy(),
        "spiculated": (n.sct_margins == 1).to_numpy(),
        "upper_lobe": n.sct_epi_loc.isin(UPPER_LOBES).to_numpy(),
        "lobe": n.sct_epi_loc.to_numpy(),
        # missing comparison record -> pre-existing; growth "cannot assess" or suspicious attenuation change -> growth
        "new": ((n.study_yr == 0) | (n.sct_ab_preexist == 1)).to_numpy(),
        "growing": (n.sct_ab_gwth.isin([2, 9]) | (n.sct_ab_attn == 2)).to_numpy(),
        "has_comparison": n.sct_ab_preexist.notna().to_numpy(),
    })
    N = N[N["mean"].notna()].reset_index(drop=True)
    S["row"] = np.arange(len(S))
    S["n_nodules"] = np.bincount(N.row, minlength=len(S))
    # fixed 4X layer: NLST-positive screen without a code-51 nodule
    S["x4"] = S.nlst_positive & (S.n_nodules == 0)
    return Dataset(S, N)
