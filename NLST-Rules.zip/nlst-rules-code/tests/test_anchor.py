"""Implementation check: comparators reproduce Pinsky 2015 within 2 percentage points."""
import os, sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from nlst_rules.data import load                                   # noqa: E402
from nlst_rules.rules import Evaluator, load_rule, complexity       # noqa: E402

RULES = os.path.join(os.path.dirname(__file__), "..", "rules", "comparators")
PINSKY = {"nlst": {"T0": (93.5, 26.6), "post": (93.8, 21.8)}, "v10": {"T0": (84.9, 12.8), "post": (78.6, 5.3)}}


@pytest.fixture(scope="module")
def ds():
    return load()


def by_round(ds, positive):
    out = {}
    for lab, m in (("T0", ds.screens.k == 0), ("post", ds.screens.k > 0)):
        m = m.to_numpy(); c = ds.screens.case.to_numpy()[m]; p = positive[m]
        out[lab] = (100 * p[c].mean(), 100 * p[~c].mean())
    return out


def test_population(ds):
    s = ds.screens
    assert len(s) == 75119 and int(s.case.sum()) == 642
    assert s[s.case].pid.is_unique                       # each cancer counted once
    assert s.pid.nunique() == 26451                       # 2 of 26,453 CT-arm participants had no completed screen


@pytest.mark.parametrize("name,positive", [("nlst", None), ("v10", "lungrads_v10.json")])
def test_reproduces_pinsky(ds, name, positive):
    ev = Evaluator(ds)
    pos = ds.screens.nlst_positive.to_numpy() if positive is None else ev.screen_positive(load_rule(os.path.join(RULES, positive)))
    got = by_round(ds, pos)
    for rnd, (sens, fpr) in PINSKY[name].items():
        assert abs(got[rnd][0] - sens) <= 2.0, (name, rnd, got[rnd])
        assert abs(got[rnd][1] - fpr) <= 2.0, (name, rnd, got[rnd])


def test_v2022_is_three_clauses(ds):
    rule = load_rule(os.path.join(RULES, "lungrads_v2022.json"))
    assert complexity(rule) == 3
    got = by_round(ds, Evaluator(ds).screen_positive(rule))
    assert 80 < got["T0"][0] < 88 and 9 < got["T0"][1] < 12        # feasibility values 83.6 / 10.7
