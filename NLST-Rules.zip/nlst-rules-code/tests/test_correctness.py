"""Correctness checks: the vectorized evaluator, the data subset, the operators, the budget and the deterministic arms
agree with simple independent implementations."""
import json, os, sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from nlst_rules.data import load, SOLID, PART, GGO                      # noqa: E402
from nlst_rules.rules import Evaluator, InvalidRule, validate, load_rule, complexity  # noqa: E402
from nlst_rules.gp import random_rule, mutate, crossover                # noqa: E402
from nlst_rules.search import Budget, nsga2, map_elites, random_search, key  # noqa: E402
from nlst_rules.gp import GPVariation                                    # noqa: E402
from nlst_rules.baselines import retuned_lungrads, retuned_rule, greedy_rules  # noqa: E402
from run_search import development_set                                    # noqa: E402

ATT_CODE = {"solid": SOLID, "part_solid": PART, "ggo": GGO}
RULES = os.path.join(os.path.dirname(__file__), "..", "rules", "comparators")


@pytest.fixture(scope="module")
def full():
    return load()


@pytest.fixture(scope="module")
def pilot(full):
    return development_set(full, "LSS", pilot=True)


def naive_positive(ds, rule):
    """Screen positivity by explicit loops over screens and nodules (independent of Evaluator)."""
    s, n = ds.screens, ds.nodules
    by_row = {}
    for rec in n.itertuples(index=False):
        by_row.setdefault(rec.row, []).append(rec)
    out = np.zeros(len(s), bool)
    for i, scr in enumerate(s.itertuples(index=False)):
        if scr.x4:
            out[i] = True
            continue
        for nod in by_row.get(scr.row, []):
            base = nod.k == 0
            new = bool(nod.new) or base
            grow = bool(nod.growing) and not base
            for c in rule["clauses"]:
                if c["round"] == "baseline" and not base or c["round"] == "followup" and base:
                    continue
                if c["status"] == "new" and not new or c["status"] == "growing" and not grow \
                        or c["status"] == "new_or_growing" and not (new or grow):
                    continue
                if nod.att not in [ATT_CODE[a] for a in c["attenuation"]] or nod.mean < c["min_size"]:
                    continue
                if c.get("spiculated") and not nod.spiculated or c.get("upper_lobe") and not nod.upper_lobe:
                    continue
                if c.get("emphysema") and not scr.emphysema or c.get("min_nodules", 0) > scr.n_nodules:
                    continue
                out[i] = True
                break
            if out[i]:
                break
    return out


def test_evaluator_matches_naive_loops(pilot):
    ev = Evaluator(pilot)
    rng = np.random.default_rng(7)
    rules = [load_rule(os.path.join(RULES, f)) for f in sorted(os.listdir(RULES))]
    rules += [random_rule(rng) for _ in range(150)]
    for r in rules:
        assert np.array_equal(ev.screen_positive(r), naive_positive(pilot, r)), json.dumps(r)


def test_subset_keeps_nodules_with_their_screens(full):
    sub = development_set(full, "ACRIN", pilot=False)
    assert (sub.screens.network == "ACRIN").all()
    s_full = full.screens.set_index(["pid", "k"])
    for rec in sub.nodules.sample(500, random_state=0).itertuples():
        scr = sub.screens.iloc[rec.row]
        assert scr.pid in s_full.index.get_level_values(0) and scr.k == rec.k
    orig = full.nodules.merge(full.screens[["row", "pid", "k"]], on="row")
    new = sub.nodules.merge(sub.screens[["row", "pid", "k"]], on="row")
    assert len(new) == (orig.pid.isin(sub.screens.pid)).sum()


def test_validate_rejects_bad_rules():
    bad = [{"clauses": []}, {"clauses": [{"attenuation": ["solid"], "min_size": 3.0}]},
           {"clauses": [{"attenuation": ["solid"], "min_size": 6.3}]}, {"clauses": [{"attenuation": [], "min_size": 6.0}]},
           {"clauses": [{"attenuation": ["solid"], "min_size": 6.0, "spiculated": False}]},
           {"clauses": [{"attenuation": ["solid"], "min_size": 6.0, "colour": "red"}]},
           {"clauses": [{"attenuation": ["solid"], "min_size": 6.0, "spiculated": True, "upper_lobe": True,
                         "emphysema": True, "min_nodules": 2}] * 2}]
    for b in bad:
        with pytest.raises(InvalidRule):
            validate(b)


def test_operators_keep_rules_valid():
    rng = np.random.default_rng(1)
    pop = [random_rule(rng) for _ in range(50)]
    for _ in range(2000):
        a, b = pop[rng.integers(50)], pop[rng.integers(50)]
        child = mutate(crossover(a, b, rng), rng)
        assert validate(child) == child and complexity(child) <= 8


def test_budget_counts_distinct_rules(pilot):
    ev = Evaluator(pilot)
    rng = np.random.default_rng(3)
    for search in ("nsga2", "map_elites", "random"):
        b = Budget(ev, 700)
        init = [random_rule(rng) for _ in range(100)]
        if search == "nsga2":
            nsga2(b, init, GPVariation(rng), rng)
        elif search == "map_elites":
            map_elites(b, init, GPVariation(rng), rng)
        else:
            random_search(b, init, random_rule, rng)
        keys = [key(r["rule"]) for r in b.archive]
        assert len(b.archive) == 700 and len(set(keys)) == 700
        for r in b.archive[:: 70]:
            m = ev.metrics(r["rule"])
            assert r["sensitivity"] == m["sensitivity"] and r["fpr"] == m["fpr"]


def test_retuned_grid_matches_rules(pilot):
    ev = Evaluator(pilot)
    g = retuned_lungrads(ev)
    rng = np.random.default_rng(5)
    for row in g[rng.integers(len(g), size=60)]:
        m = ev.metrics(retuned_rule(*row[:4]))
        assert np.isclose(m["sensitivity"], row[4]) and np.isclose(m["fpr"], row[5])


def test_greedy_rules_are_valid_and_improve(pilot):
    ev = Evaluator(pilot)
    rules = greedy_rules(ev)
    assert rules
    for r in rules:
        assert validate(r["rule"]) == r["rule"]


class _Empty:
    """Offspring generator that never returns a rule."""
    name = "empty"

    def offspring(self, parents, n):
        return []


def test_searches_stop_when_no_offspring(pilot):
    ev = Evaluator(pilot)
    rng = np.random.default_rng(9)
    init = [random_rule(rng) for _ in range(100)]
    for search in (nsga2, map_elites):
        b = Budget(ev, 5000)
        search(b, init, _Empty(), rng)
        assert b.stalled and len(b.archive) <= 100
